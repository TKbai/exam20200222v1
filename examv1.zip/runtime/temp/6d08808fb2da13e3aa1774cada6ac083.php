<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:88:"D:\phpstudy_pro\WWW\webroot\examv1\public/../application/voluntary\view\index\index.html";i:1584607172;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>山东省高考志愿辅助决策系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.css">
	<link rel="stylesheet" href="/public/static/css/style.css">
    <style>caption {font-size: 18.72px;
	}
	</style>
  </head>
  <body>
    <div class="container">
      <div class="row clearfix">
        <div class="col-md-12 column">
        </div>
      </div>
      <div class="row clearfix">
        <div class="col-md-12 column">
		  <ul class="nav nav-tabs">
		    <li><a href="<?php echo url('notice/index/index'); ?>">通知公告</a></li>
			<li><a href="<?php echo url('data/index/index'); ?>">权威数据</a></li>
			<li><a href="<?php echo url('university/index/index'); ?>">院校库</a></li>
			<li><a href="<?php echo url('major/index/index'); ?>">专业库</a></li>
			<li class="active"><a href="<?php echo url('voluntary/index/index'); ?>">填志愿</a></li>
			<li><a href="#">收藏的院校</a></li>
			<li><a href="#">收藏的专业</a></li>
		  </ul>
        </div>
      </div>
      <div class="container">
        <div class="row clearfix">
      	  <div class="col-md-offset-3 col-md-6 column">
      	    <table class="table table-bordered table-hover">
      		  <caption class="text-center">通知公告</caption>
      		    <tr>
      			  <th>标题</th>
      			  <th>网址</th>
      			  <th>日期</th>
      			  <th>操作</th>
				  <th>操作</th>
				  <th>操作</th>
      			</tr>
      			<?php if(is_array($voluntary) || $voluntary instanceof \think\Collection || $voluntary instanceof \think\Paginator): $i = 0; $__LIST__ = $voluntary;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$voluntary): $mod = ($i % 2 );++$i;?>
      			<tr>
      			  <td><?php echo $voluntary['voluntary_title']; ?></td>
      			  <td><?php echo $voluntary['voluntary_web']; ?></td>
      			  <td><?php echo $voluntary['voluntary_date']; ?></td>
      			  <td>
      			    <i class="fa fa-edit" style="color: green"></i>
      				<a href="<?php echo url('edit', ['voluntary_id'=>$voluntary['voluntary_id']]); ?>" onclick="return confirm('确认修改这条公告吗？')">修改</a>
      				<i class="fa fa-trash" style="color: darkred"></i>
      				<a href="<?php echo url('delete', ['voluntaryId'=>$voluntary['voluntary_id']]); ?>" onclick="return confirm('确认删除这条公告吗？')">删除</a>
      			  </td>
      			</tr>
      			<?php endforeach; endif; else: echo "" ;endif; ?>
			</table>
      	  </div>
		  <div class="col-md-offset-3 col-md-6 text-right">
		    <i class="fa fa-plus" style="color: green"></i>
		    <a href="<?php echo url('add'); ?>" onclick="return confirm('确认添加公告吗？')">添加</a>
		  </div>
      	  <div class="col-md-offset-3 col-md-6 column">
	        <div class="pagination pull-right">
			  <?php echo $voluntary->render(); ?>
		    </div>
      	  </div>
      	</div>
      </div>
      <div class="row clearfix">
        <div class="col-md-12 column">
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
  </body>
</html>
<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"D:\phpstudy_pro\WWW\webroot\examv1\public/../application/major\view\index\major.html";i:1584707757;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>
        山东省高考志愿辅助决策系统
    </title>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <link rel="stylesheet" href="/public/static/css/base.css" type="text/css">
     <link href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.css">
</head>
<body>
    <div id="barrierfree_container">
        <form method="post" action="" id="form1">
            <div class="aspNetHidden">
            </div>
            <div class="aspNetHidden">
                <div class="top">
                    <div class="contain">
                        <p>欢迎使用山东省高考辅助决策系统！</p>
                        <div class="fr">
                            <a href="user/index/login">登录</a>
                            <a href="user/index/register">注册</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="contain topBanaer">
                <img src="../../../../public/static/img/logo.jpg" alt="" />
                <ul class="topnav">
                    <li id="nav1" ><a href="<?php echo url('index/index/index'); ?>">网站首页</a></li>
                    <li id="nav2"><a href="<?php echo url('notice/index/notice'); ?>">通知公告</a></li>
                    <li id="nav3"><a href="<?php echo url('data/index/data'); ?>">权威数据</a></li>
                    <li id="nav4"><a href="<?php echo url('university/index/university'); ?>">院校查询</a></li>
                    <li id="nav5" class="none on"><a href="<?php echo url('major/index/major'); ?>">专业查询</a></li>
                    <li id="nav6"><a href="<?php echo url('voluntary/index/voluntary'); ?>">模拟志愿</a></li>
                </ul>
            </div>
   
        <div class="container">
            <div class="row clearfix">
                <div class="col-md-12 column">
                    <form class="form-horizontal" action="<?php echo url('index/major'); ?>" method="post">
                        <div class="form-group">
                            <label for="major_name" class="col-sm-offset-2 col-sm-2 control-label">
                                专业名称：
                            </label>
                            <div class="col-sm-2 col-md-pull-1 " style="margin-top: -5px">
                                 <input type="text" class="form-control" id="major_name" name="major_name" placeholder="请输入专业名称"  autocomplete="off">
                            </div>
                            <label for="major_level" class="col-sm-2 control-label">
                                学科评估结果：
                            </label>
                            <div class="col-sm-2 col-md-pull-1" style="margin-top: -5px">
                                <select name="major_level" id="major_level"class="form-control">
                                    <option value="全部">全部</option>
                                    <option value="A+">A+</option>
                                    <option value="A">A</option>
                                    <option value="A-">A-</option>
                                    <option value="B+">B+</option>
                                    <option value="B">B</option>
                                    <option value="B-">B-</option>
                                    <option value="C+">C+</option>
                                    <option value="C">C</option>
                                    <option value="C-">C-</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="major_type" class="col-sm-offset-2 col-sm-2 control-label" style="margin-top: 15px">
                                专业类别：
                            </label>
                            <div class="col-sm-2 col-md-pull-1 " style="margin-top: 8px">
                                <select name="major_type" id="major_type" class="form-control" style="margin-top: 0px">
                                    <option value="全部">全部</option>
                                    <option value="工学">工学</option>
                                    <option value="管理学">管理学</option>
                                    <option value="理学">理学</option>
                                    <option value="农学">农学</option>
                                    <option value="人文社科类">人文社科类</option>
                                    <option value="医学">医学</option>
                                </select>
                            </div>
                            <label for="first_discipline" class="col-sm-offset-0 col-sm-2 control-label" style="margin-top: 15px">一流学科：
                            </label>
                            <div class="col-sm-2">
                                <div class="radio col-md-pull-7" style="margin-top: 15px">
                                    <label>
                                        <input type="radio" name="first_discipline" id="first_discipline" value=1>是
                                    </label>                                                             
                                    <label>                                                              
                                        <input type="radio" name="first_discipline" id="first_discipline" value=0>否
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="university_name" class="col-sm-7 col-sm-offset-2 control-label" style="padding-left: 15px; margin-top: 10px">
                               院校名称：
                            </label>
                            <div class="col-sm-2 col-md-pull-6" style="margin-top: 5px">
                                <input type="text" class="form-control" id="university_name" name="university_name" placeholder="请输入院校名称"autocomplete="off">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="col-sm-offset-2 col-sm-2 control-label" style="margin-top: 15px">
                                预估分数：
                            </label>
                            <div class="col-sm-1 col-md-pull-1 " style="margin-top: 8px">
                                <input type="text" class="form-control" id="score_min" name="score_min" placeholder="下限"autocomplete="off">
                            </div>
                            <div class="col-sm-1 col-md-pull-1 " style="margin-top: 8px; ">
                                 <input type="text" class="form-control" id="score_max" name="score_max" placeholder="上限" autocomplete="off">
                            </div>
                            <label for="" class="col-md-pull-0 col-sm-2 control-label" style="margin-top: 15px">
                                预估位次：
                            </label>
                            <div class="col-sm-1 col-md-pull-1 " style="margin-top: 8px">
                                  <input type="text" class="form-control" id="pos_min" name="pos_min" placeholder="下限" autocomplete="off">
                            </div>                                                                   
                            <div class="col-sm-1 col-md-pull-1 " style="margin-top: 8px">            
                                  <input type="text" class="form-control" id="pos_max" name="pos_max" placeholder="上限"autocomplete="off">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-5 col-sm-4">
                                <button type="submit" class="btn btn-default">查询</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="content" style="margin-top: 10px; padding-left: 45px ;">
                    <div class="container">
                        <div class="row clearfix">
                            <div class="col-md-12 column">
                                <div style="overflow:auto;width: 90%" >
                                    <table class="table table-bordered table-hover table-condensed table-responsive" id="table-3">
                                        <thead>
                                            <tr>
                                                <th>院校代号</th>
                                                <th>院校名称</th>
                                                <th>专业名称</th>
                                                <th>专业类别</th>
                                                <th>学科评估</th>
                                                <th>2019录取最低分</th>
                                                <th>2018录取最低分</th>
                                                <th>2017录取最低分</th>
                                                <th>2019最低位次</th>
                                                <th>2018最低位次</th>
                                                <th>2017最低位次</th>
                                                <th>2019平均分</th>
                                                <th>2018平均分</th>
                                                <th>2017平均分</th>
                                                <th>选考科目要求</th>
                                                <th>一流学科</th>
                                            </tr>
                                        </thead>
                                        <?php if(is_array($majors) || $majors instanceof \think\Collection || $majors instanceof \think\Paginator): $i = 0; $__LIST__ = $majors;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$major): $mod = ($i % 2 );++$i;?>
                                        <tbody>
                                            <tr>
                                                <td><?php echo $major['university_code']; ?></td>
                                                <td><?php echo $major['university_name']; ?></td> 
                                                <td><?php echo $major['major_name']; ?></td>
                                                <td><?php echo $major['major_type']; ?></td>
                                                <td><?php echo $major['major_level']; ?></td>
                                                <td><?php echo $major['min2019']; ?></td>
                                                <td><?php echo $major['min2018']; ?></td>
                                                <td><?php echo $major['min2017']; ?></td>
                                                <td><?php echo $major['pos2019']; ?></td>
                                                <td><?php echo $major['pos2018']; ?></td>
                                                <td><?php echo $major['pos2017']; ?></td>
                                                <td><?php echo $major['ave2019']; ?></td>
                                                <td><?php echo $major['ave2018']; ?></td>
                                                <td><?php echo $major['ave2017']; ?></td>
                                                <td><?php echo $major['subject_limit']; ?></td>
                                                <td><?php if($major['first_discipline'] == 1): ?><i class="fa fa-check" style="color: green" ></i><?php endif; ?></td>
                                            </tr>
                                        </tbody>
                                         <?php endforeach; endif; else: echo "" ;endif; ?>
                                     </table>
                                 </div>
                             </div>
                             <div class="col-md-12 column" >
                                 <div class="pagination pull-right" >
                                      <?php echo $majors->render(); ?>
                                 </div>
                             </div>
                         </form>
                     </div>
                 </div>
             </div>
         </div>
             <div class="contain fot-txt">
                 <div class="fotNav">
                    <span style="display:block;padding-left:320px;padding-top: 20px">Copyright  &copy; 2020
                        <a id="pixinventLink" target="_blank" class="text-bold-800 primary darken-2">
                            济南凤鸣科技工作室
                        </a>
                           ,All rights reserved. 
                    </span>   
                </div> 
            </div>
        </form>
    </div>
</body>
</html>

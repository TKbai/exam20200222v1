<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"D:\webroot\examv1\public/../application/index\view\index\notice_edit.html";i:1581649459;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="/public/static/css/style.css">
	<style>
		/*第一列文字左对齐*/
		td:nth-child(1) {
			text-align: center;
		}
	</style>
	<title>修改权威数据</title>
</head>
<body>
<div class="container">
	<div class="row clearfix">
		<div class="col-md-offset-3 col-md-6 column">
			<div class="content">
				<form method="post">
					<table class="table table-bordered">
						<caption class="text-center ">修改权威数据</caption>
						<tr>
							<td>标题</td>
							<td>
								<input type="text" name="notice_title" id="notice_title" value="<?php echo $notice['notice_title']; ?>">
							</td>
						</tr>
						<tr>
							<td>网址</td>
							<td>
								<input type="text" name="notice_web" id="notice_web" value="<?php echo $notice['notice_web']; ?>" required>
								<span style="color: red">*必填项</span>
							</td>
						</tr>
						<tr>
							<td>日期</td>
							<td>
								<input type="text" name="notice_date" id="notice_date" value="<?php echo $notice['notice_date']; ?>">
							</td>
						</tr>
						<tr>
							<td colspan="2" style="text-align: center;"">
							<input type="submit" value="保存">
							<input type="button" value="返回" onclick="window.history.back()">
							</td>
						</tr>
					</table>
				</form>
			</div>
		</div>
	</div>
</div>
</body>
</html>
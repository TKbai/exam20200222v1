<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:82:"D:\phpstudy_pro\WWW\webroot\examv1\public/../application/data\view\index\data.html";i:1584707493;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>
  山东省高考志愿辅助决策系统
    </title>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <link rel="stylesheet" href="/public/static/css/base.css" type="text/css" />
     <link href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.css">
</head>
<body>
    <div id="barrierfree_container">
        <form method="post" action="./" id="form1">
            <div class="aspNetHidden">
            </div>
            <div class="aspNetHidden">
                <div class="top">
                    <div class="contain">
                        <p>欢迎使用山东省高考辅助决策系统！</p>
                        <div class="fr">
                            <a href="<?php echo url('user/index/login'); ?>">登录</a>
                            <a href="<?php echo url('user/index/register'); ?>">注册</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="contain topBanaer">
                <img src="../../../../public/static/img/logo.jpg" alt="" />
                <ul class="topnav">
                    <li id="nav1" ><a href="<?php echo url('index/index/index'); ?>">网站首页</a></li>
                    <li id="nav2"><a href="<?php echo url('notice/index/notice'); ?>">通知公告</a></li>
                    <li id="nav3" class="none on"><a href="<?php echo url('data/index/data'); ?>">权威数据</a></li>
                    <li id="nav4"><a href="<?php echo url('university/index/university'); ?>">院校查询</a></li>
                    <li id="nav5"><a href="<?php echo url('major/index/major'); ?>">专业查询</a></li>
                    <li id="nav6"><a href="<?php echo url('voluntary/index/voluntary'); ?>">模拟志愿</a></li>
                </ul>
            </div>
            <div class="content" style="padding-left:45px;height: 400px;">
                <div class="row clearfix">
                    <div class="col-md-12 column">
                        <a href="http://edu.shandong.gov.cn/art/2020/1/9/art_114775_8634265.html"  style="padding-left: 220px">动漫视频：山东省2020年“新高考”问答</a></br>
                        <a href="http://edu.shandong.gov.cn/art/2019/12/16/art_11992_8358324.html"  style="padding-left:220px">山东省2020年高考政策30问</a></br>
                        <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4590"  style="padding-left: 220px">山东省2020年普通高校招生考试录取政策和志愿填报百问百答（试用版）</a></br>
                        <a href="http://xkkm.sdzk.cn/zy-manager-web/gxxx/selectAllDq#"  style="padding-left: 220px">2020年拟在山东招生普通高校专业（类）选考科目要求</a></br>
                        <a href="http://gaokao.eol.cn/news/201906/t20190617_1664626.shtml"  style="padding-left: 220px">教育部：2019年全国高等学校名单</a></br>
                        <a href=" http：//wsbm.sdzk.cn"  style="padding-left: 220px"> 山东高考报名系统入口</a></br>
                        <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4722"  style="padding-left: 220px">近三年普通高考本科普通批首次志愿录取情况统计表</a>
                    </div>
                </div>
            </div>
            <div class="contain fot-txt">
                <div class="fotNav">
                    <span style="display:block;padding-left:320px;padding-top: 20px">Copyright  &copy; 2020
                     济南凤鸣科技工作室
                     ,All rights reserved. 
                   </span>   
               </div> 
           </div>
      </form>
  </div>
</body>
</html>

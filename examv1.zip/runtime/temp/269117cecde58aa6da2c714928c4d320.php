<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:94:"D:\phpstudy_pro\WWW\webroot\examv1\public/../application/university\view\index\university.html";i:1584608312;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>
        山东省高考志愿辅助决策系统
    </title>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <link rel="stylesheet" href="/public/static/css/base.css" type="text/css" />
    <link href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.css">
    <link href="https://cdn.bootcss.com/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">   
    <link href="https://cdn.bootcss.com/bootstrap-table/1.12.2/bootstrap-table.css" rel="stylesheet">
    <link href="https://cdn.bootcss.com/bootstrap-table/1.12.2/extensions/reorder-rows/bootstrap-table-reorder-rows.css" rel="stylesheet">

</head>
<body>
    <div id="barrierfree_container">
         <form method="post" action="" id="form1">
            <div class="aspNetHidden">
            </div>
            <div class="aspNetHidden">
                <div class="top">
                    <div class="contain">
                        <p>欢迎使用山东省高考辅助决策系统！</p>
                        <div class="fr">
                            <a href="<?php echo url('user/index/login'); ?>">登录</a>
                            <a href="<?php echo url('user/index/register'); ?>">注册</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="contain topBanaer">
                <img src="../../../../public/static/img/logo.jpg">
                <ul class="topnav">
                    <li id="nav1" ><a href="<?php echo url('index/index/index'); ?>">网站首页</a></li>
                    <li id="nav2"><a href="<?php echo url('notice/index/notice'); ?>">通知公告</a></li>
                    <li id="nav3"><a href="<?php echo url('data/index/data'); ?>">权威数据</a></li>
                    <li id="nav4" class="none on"><a href="<?php echo url('university/index/university'); ?>">院校查询</a></li>
                    <li id="nav5"><a href="<?php echo url('major/index/major'); ?>">专业查询</a></li>
                    <li id="nav6"><a href="<?php echo url('voluntary/index/voluntary'); ?>">模拟志愿</a></li>
                </ul>
            </div>
            <div class="container">
                <div class="row clearfix">
                    <div class="col-md-12 column">
                        <form class="form-horizontal" action="<?php echo url('index/university'); ?>" method="post">
                             <div class="form-group">
                                 <label for="university_name" class="col-sm-offset-2 col-sm-2 control-label">
                                    院校名称：
                                 </label>
                                 <div class="col-sm-2 col-md-pull-1">
                                     <input type="text" class="form-control" id="university_name" name="university_name" placeholder="请输入院校名字"autocomplete="off">
                                 </div>
                                 <label for="type" class="col-sm-2 control-label">
                                    院校类型：
                                 </label>
                                 <div class="col-sm-2 col-md-pull-1">
                                     <select name="type" id="type" class="form-control">
                                         <option value="全部">全部</option>
                                         <option value="综合">综合</option>
                                         <option value="工科">工科</option>
                                         <option value="农业">农业</option>
                                         <option value="林业">林业</option>
                                         <option value="医药">医药</option>
                                         <option value="师范">师范</option>
                                         <option value="语言">语言</option>
                                         <option value="财经">财经</option>
                                         <option value="政法">政法</option>
                                         <option value="体育">体育</option>
                                         <option value="艺术">艺术</option>
                                         <option value="民族">民族</option>
                                     </select>
                                 </div>
                             </div>
                             <div class="form-group">
                                 <label for="university_level" class="col-sm-offset-2 col-sm-2 control-label">办学层次：
                                 </label>
                                 <div class="col-sm-2">
                                     <div class="radio col-md-pull-7">
                                         <label>
                                             <input type="radio" name="university_level" id="university_level" value="本科" checked>本科
                                         </label>
                                         <label>
                                             <input type="radio" name="university_level" id="university_level" value="专科">专科
                                         </label>
                                     </div>
                                 </div>
                                 <label for="university" class="col-sm-2 control-label">
                                     院校层次：
                                 </label>
                                 <div class="col-sm-4 col-md-pull-1">
                                     <div class="radio">
                                         <label>
                                             <input type="radio" value="985" name="university_985" id="university_985">985
                                         </label>
                                         <label>
                                             <input type="radio" value="211" name="university_211" id="university_211">211
                                         </label>
                                         <label>
                                             <input type="radio" value="一流大学" name="first_class" id="first_class">一流大学
                                         </label>
                                     </div>
                                 </div>
                             </div>
                             <div class="form-group">
                                 <div class="col-sm-offset-6 col-sm-4">
                                     <button type="submit" class="btn btn-default">查询</button>
                                 </div>
                             </div>
                         </form>
                     </div>
                     <div class="row clearfix" style="margin-top: 10px; padding-left: 100px;width: 95%">
                         <div class="col-md-12 column">
                             <div style="overflow: auto;">
                                 <table class="table table-bordered table-hover table-condensed table-responsive" id="table-3">
                                     <thead>
                                         <tr>
                                            <th>院校名称</th>
                                            <th>省份</th>
                                            <th>城市</th>
                                            <th>主管部门</th>
                                            <th>办学层次</th>
                                            <th>排名</th>
                                            <th>985大学</th>
                                            <th>211大学</th>
                                            <th>一流大学建设高校</th>
                                            <th>学校官网</th>
                                            <th>招生章程</th>
                                            <th>备注</th>
                                         </tr>
                                     </thead>
                                         <?php if(is_array($universities) || $universities instanceof \think\Collection || $universities instanceof \think\Paginator): $i = 0; $__LIST__ = $universities;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$university): $mod = ($i % 2 );++$i;?>
                                         <tbody>
                                             <tr>
                                                <td><?php echo $university['university_name']; ?></td>
                                                <td><?php echo $university['province']; ?></td>
                                                <td><?php echo $university['city']; ?></td>
                                                <td><?php echo $university['department']; ?></td>
                                                <td><?php echo $university['university_level']; ?></td>
                                                <td><?php echo $university['university_order']; ?></td>
                                                <td>
                                                    <?php if($university['university_985'] == 1): ?>
                                                    <i class="fa fa-check" style="color: green"></i>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php if($university['university_211'] == 1): ?><i class="fa fa-check" style="color: green" ><?php endif; ?></td>
                                                <td><?php if($university['first_class'] == 1): ?><i class="fa fa-check" style="color: green"></i><?php endif; ?></td>
                                                <td>
                                                    <a href="<?php echo $university['website']; ?>">访问</a>
                                                </td>
                                                <td>
                                                    <a href="<?php echo $university['charter']; ?>">访问</a>
                                                </td>
                                                 <td><?php echo $university['comment']; ?></td>
                                              </tr>
                                          </tbody>
                                          <?php endforeach; endif; else: echo "" ;endif; ?>
                                      </table>
                                  </div>
                              </div>
                              <div class="col-md-12 column">
                                  <div class="pagination pull-right">
                                      <?php echo $universities->render(); ?>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="contain fot-txt">
                  <div class="fotNav">
                      <span style="display:block;padding-left:320px;padding-top: 20px">Copyright  &copy; 2020
                          <a id="pixinventLink" target="_blank" class="text-bold-800 primary darken-2">
                             济南凤鸣科技工作室
                          </a>
                             ,All rights reserved. 
                     </span>   
                 </div> 
             </div>
         </form>
     </div>
</body>
</html>
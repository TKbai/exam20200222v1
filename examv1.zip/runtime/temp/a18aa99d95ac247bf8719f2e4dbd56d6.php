<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"D:\phpstudy_pro\WWW\webroot\examv1\public/../application/notice\view\index\notice.html";i:1584617619;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>
  山东省高考志愿辅助决策系统
    </title>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <link rel="stylesheet" href="/public/static/css/base.css" type="text/css" />
     <link href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.css">
</head>
<body>
    <div id="barrierfree_container">
        <form method="post" action="./" id="form1">
            <div class="aspNetHidden">
            </div>
            <div class="aspNetHidden">
                <div class="top">
                    <div class="contain">
                        <p>欢迎使用山东省高考辅助决策系统！</p>
                        <div class="fr">
                            <a href="<?php echo url('user/index/login'); ?>">登录</a>
                            <a href="<?php echo url('user/index/register'); ?>">注册</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="contain topBanaer">
               <img src="../../../../public/static/img/logo.jpg" alt="" />
                <ul class="topnav">
                    <li id="nav1" ><a href="<?php echo url('index/index/index'); ?>">网站首页</a></li>
                    <li id="nav2" class="none on"><a href="<?php echo url('notice/index/notice'); ?>">通知公告</a></li>
                    <li id="nav3" ><a href="<?php echo url('data/index/data'); ?>">权威数据</a></li>
                    <li id="nav4" ><a href="<?php echo url('university/index/university'); ?>">院校查询</a></li>
                    <li id="nav5"><a href="<?php echo url('major/index/major'); ?>">专业查询</a></li>
                    <li id="nav6"><a href="<?php echo url('voluntary/index/voluntary'); ?>">模拟志愿</a></li>
                </ul>
            </div>
            <div class="content" style="height: 400px;">
            
                <div class="row clearfix">
                    <div class="col-md-12 column">
                        <li class="news-item">
                            <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4735"  title="关于暂停办理普通高考、自学考试证明的公告" target="_blank" style="padding-left: 260px;">关于暂停办理普通高考、自学考试证明的公告</a>
                        </li>
                        
                        <li class="news-item">
                            <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4752"  title="关于2020年4月山东省高等教育自学考试延期举行的公告" target="_blank" style="padding-left: 260px">关于2020年4月山东省高等教育自学考试延期举行的公告</a>
                        </li>
                        
                        <li class="news-item">
                            <a href="www.sdzk.cn/NewsInfo.aspx?NewsID=4753
"  title="关于山东省2019年冬季普通高中学业水平考试和" target="_blank" style="padding-left: 260px">关于山东省2019年冬季普通高中学业水平考试和...</a>
                        </li>
                        
                        <li class="news-item">
                            <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4729"  title="关于《2020年山东省普通高等学校招生考试（春季）考试说明》更正通知" target="_blank" style="padding-left: 260px">关于《2020年山东省普通高等学校招生考试（春季）考试说明》更正通知</a>
                        </li>                        
                    </div>
                </div>
            </div>
        </div>
        <div class="contain fot-txt">
            <div class="fotNav">
                <span style="display:block;padding-left:320px;padding-top: 20px">Copyright  &copy; 2020
                       济南凤鸣科技工作室
                      ,All rights reserved. 
                </span>   
            </div> 
        </div>
    </form>
</div>
</body>
</html>

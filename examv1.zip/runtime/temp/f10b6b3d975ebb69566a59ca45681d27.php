<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:66:"D:\webroot\examv1\public/../application/user\view\index\login.html";i:1583760707;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>山东省高考志愿辅助决策系统</title>
	<link rel="stylesheet" type="text/css" href="/public/static/css/register-login.css">
</head>
    <body>
    	<div id="box"></div>
        <div class="cent-box">
	        <div class="cent-box-header" style="margin-top: -70px;">
		        <h1 class="main-title hide" ></h1>
		        <h2 class="sub-title">山东省高考志愿辅助决策系统</h2>
	        </div>
	        <div class="cont-main clearfix">
		        <div class="index-tab" style="margin-top: -20px;">
			        <div class="index-slide-nav">
				        <a href="login.html" class="active">登录</a>
				        <a href="register.html">注册</a>
				        <div class="slide-bar"></div>				
			        </div>
		        </div>
		        <div class="login form" style="margin-top: -10px;">
			        <div class="group">
				        <div class="group-ipt email">
					        <input type="text" name="username" id="username" class="ipt" placeholder="请输入您的用户名" required>
				        </div>
				        <div class="group-ipt password">
					        <input type="password" name="password" id="password" class="ipt" placeholder="请输入您的登录密码" required>
				        </div>
				        <div class="group-ipt verify">
					        <input type="text" name="verify" id="verify" class="ipt" placeholder="输入验证码" required>
					        <img name="verify_img" id="verify_img" src="<?php echo captcha_src(); ?>" alt="验证码">
					        <a href="javascript:showcode()">看不清，换一张</a>
				        </div>
			        </div>
		        </div>
		        <div class="button">
			        <button type="submit" class="login-btn register-btn" id="button">登录</button>
		        </div>
		        <div class="remember clearfix">
			        <label class="remeber-me">
				        <input type="checkbox" name="sex">记住密码
			        </label>
			        <label class="forgot-password">
				         <a href="#">忘记密码？</a>
			        </label>
		        </div>
	        </div>
        </div>
        <div class="footer">
	        <span>Copyright  &copy; 2020
                <a id="pixinventLink" target="_blank" class="text-bold-800 primary darken-2">
                    济南凤鸣科技工作室
                </a>
                ,All rights reserved. 
            </span>
        </div>
        <script src='/public/static/js/particles.js' type="text/javascript"></script> 
        <script src='/public/static/js/background.js' type="text/javascript"></script> 
        <script>
            function showcode()
           {
            var img = document.getElementById('verify_img');
            img.src = "<?php echo captcha_src(); ?>?id="+new Date(); //增加一个随机参数，防止图片缓存
            return false; //阻止超链接的跳转动作
           }
        </script>
    </body>
</html>
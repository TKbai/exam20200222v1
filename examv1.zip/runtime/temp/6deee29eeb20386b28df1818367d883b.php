<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"D:\phpstudy_pro\WWW\webroot\examv1\public/../application/index\view\index\index.html";i:1584627934;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>
    山东省高考志愿辅助决策系统
    </title>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <link rel="stylesheet" href="/public/static/css/base.css" type="text/css">
    <script type="text/javascript" src="/public/static/js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="/public/static/js/jquery.SuperSlide.2.1.1.js"></script>
</head>
<body>
    <div id="barrierfree_container">
        <form method="post" action="" id="form1">
            <div class="aspNetHidden">
            </div>
            <div class="aspNetHidden">
                <div class="top">
                    <div class="contain">
                        <p>欢迎使用山东省高考辅助决策系统！</p>
                        <div class="fr">
                            <a href="<?php echo url('user/index/login'); ?>">登录</a>
                            <a href="<?php echo url('user/index/register'); ?>">注册</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="contain topBanaer">
                <img src="img/logo.jpg" alt="">
                <ul class="topnav">
                    <li id="nav1" class="none on"><a href="<?php echo url('index/index/index'); ?>">网站首页</a></li>
                    <li id="nav2"><a href="<?php echo url('notice/index/notice'); ?>">通知公告</a></li>
                    <li id="nav3"><a href="<?php echo url('data/index/data'); ?>">权威数据</a></li>
                    <li id="nav4"><a href="<?php echo url('university/index/university'); ?>">院校查询</a></li>
                    <li id="nav5"><a href="<?php echo url('major/index/major'); ?>">专业查询</a></li>
                    <li id="nav6"><a href="<?php echo url('voluntary/index/voluntary'); ?>">模拟志愿</a></li>
                </ul>
            </div>            
    <div class="contain News">
        <div class="focusBox">
            <div class="hd">
                <ul>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>
            </div>
            <div class="focuspic">                
                
                        <div class="zzy">
                            <a href="" title="" target="_blank">
                                <img src="../../../../public/static/img/timg.jpg"  style="width: 380px; height: 237px;" />
                                <dl>
                                    <dt>清华大学官网</dt>
                                    <dd>2019-03-08</dd>
                                </dl></a>
                           <a href="" class="jump">More>></a>
                        </div>
                    
                        <div class="zzy">
                            <a href="NewsInfo.aspx?NewsID=4714" title="" target="_blank">
                                <img src="../../../../public/static/img/timg1.jpg"  style="width: 380px; height: 237px;" />
                                <dl>
                                    <dt>复旦大学官网</dt>
                                    <dd>2020-03-08</dd>
                                </dl></a>
                           <a href="" class="jump">More>></a>
                        </div>
                    
                        <div class="zzy">
                            <a href="NewsInfo.aspx?NewsID=4542" title="" target="_blank">
                                <img src="../../../../public/static/img/timg2.jpg"  style="width: 380px; height: 237px;" />
                                <dl>
                                    <dt>北京大学官网</dt>
                                    <dd>2019-03-08</dd>
                                </dl></a>
                           <a href="" class="jump">More>></a>
                        </div>
                    
                        <div class="zzy">
                            <a href="" title="" target="_blank">
                                <img src="../../../../public/static/img/timg3.jpg"  style="width: 380px; height: 237px;" />
                                <dl>
                                    <dt>上海交通大学官网</dt>
                                    <dd>2019-03-08</dd>
                                </dl></a>
                           <a href="/NewsList.aspx?BCID=1&CID=18" class="jump">More>></a>
                        </div>
                    

            </div>
        </div>
        <div class="newsTab">
            <div class="hd">
                <ul>
                    <li><a href="<?php echo url('notice/index/notice'); ?>">最新公告</a></li>
                    <li><a href="<?php echo url('data/index/data'); ?>">最新数据</a></li>
                </ul>
            </div>
            <div class="bd">
                <ul>
                    <li class="news-item">
                        <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4735"  title="关于暂停办理普通高考、自学考试证明的公告" target="_blank">关于暂停办理普通高考、自学考试证明的公告</a>
                    </li>
                        
                    <li class="news-item">
                        <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4752"  title="关于2020年4月山东省高等教育自学考试延期举行的公告" target="_blank">关于2020年4月山东省高等教育自学考试延期举行的公告</a>
                    </li>
                        
                    <li class="news-item">
                        <a href="www.sdzk.cn/NewsInfo.aspx?NewsID=4753
"  title="关于山东省2019年冬季普通高中学业水平考试和" target="_blank">关于山东省2019年冬季普通高中学业水平考试和...</a>
                    </li>
                        
                    <li class="news-item">
                        <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4729"  title="关于《2020年山东省普通高等学校招生考试（春季）考试说明》更正通知" target="_blank">关于《2020年山东省普通高等学校招生考试（春季）考试说明》更正通知</a>
                    </li>                        
                </ul>
                <ul>
                    <li class="news-item">
                        <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4722"  title="近三年普通高考本科普通批首次志愿录取情况统计表" target="_blank">近三年普通高考本科普通批首次志愿录取情况统计表</a>
                    </li>
                        
                    <li class="news-item">
                        <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4721"  title="2020年夏季高考和普通高中学业水平等级模拟考试文化成绩一分一段表" target="_blank">2020年夏季高考和普通高中学业水平等级模拟考试文化成绩一分一段表</a>
                    </li>

                    <li class="news-item">
                        <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4718"  title="山东省2020年夏季高考模拟录取各类别分数线" target="_blank">山东省2020年夏季高考模拟录取各类别分数线</a>
                    </li>
                        
                    <li class="news-item">
                        <a href="http://xkkm.sdzk.cn/zy-manager-web/gxxx/selectAllDq#"  title="2020年拟在山东招生普通高校专业（类）选考科目要求" target="_blank">2020年拟在山东招生普通高校专业（类）选考科目要求</a>
                    </li>
                        
                    <li class="news-item">
                        <a href="http://gaokao.eol.cn/news/201906/t20190617_1664626.shtml"  title="教育部：2019年全国高等学校名单" target="_blank">教育部：2019年全国高等学校名单</a>
                    </li>
                   
                    <li class="news-item">
                        <a href="http://edu.shandong.gov.cn/art/2019/12/16/art_11992_8358324.html"  title="山东省2020年高考政策30问" target="_blank">山东省2020年高考政策30问</a>
                    </li>
                        
                    <li class="news-item">
                        <a href="http://edu.shandong.gov.cn/art/2020/1/9/art_114775_8634265.html7"  title="动漫视频：山东省2020年“新高考”问答" target="_blank">动漫视频：山东省2020年“新高考”问答</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>


    <div class="contain ksy-txt">
        <dl>
            <dt>
                <span>
                    <a href="NewsList.aspx?BCID=1&CID=14" target="_blank">通知公告</a>
                </span>
            </dt>           
            <dd>  
                <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4735"  title="关于暂停办理普通高考、自学考试证明的公告" target="_blank">关于暂停办理普通高考、自学考试..
                </a>
            </dd>    
            <dd>
                <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4752"  title="关于2020年4月山东省高等教育自学考试延期举行的公告" target="_blank">关于2020年4月山东省高等教育..
                </a>
            </dd>    
            <dd>
                <a href="www.sdzk.cn/NewsInfo.aspx?NewsID=4753
                  "title="关于山东省2019年冬季普通高中学业水平考试和" target="_blank">关于山东省2019年冬季普通高中学业水平..
                </a>
            </dd>    
            <dd>
                <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4729"  title="关于《2020年山东省普通高等学校招生考试（春季）考试说明》更正通知" target="_blank">关于《2020年山东省普通高等学校招生考试..
                </a>
            </dd>            
        </dl>
        <dl>
            <dt>
                <span>
                    <a href="NewsList.aspx?BCID=1&CID=14" target="_blank">权威数据
                    </a>
                </span>
            </dt>           
            <dd> 
                <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4403"  title="2019年投档情况统计表专科（高职）普通批征集志愿" target="_blank">2019年投档情况统计表专科（高职）普通批..
                </a>
            </dd>    
            <dd>
                <a href="http://edu.shandong.gov.cn/art/2020/1/9/art_114775_8634265.html7"  title="动漫视频：山东省2020年“新高考”问答" target="_blank">动漫视频：山东省2020年“新高考”问答
                </a>
            </dd>
            <dd>
                <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4718"  title="山东省2020年夏季高考模拟录取各类别分数线" target="_blank">山东省2020年夏季高考模拟录取各类别分数线
                </a>
            </dd>
            <dd> 
                <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4722"  title="近三年普通高考本科普通批首次志愿录取情况统计表" target="_blank">近三年普通高考本科普通批首次志愿..
                </a>
            </dd>
            <dd> 
                <a href="http://xkkm.sdzk.cn/zy-manager-web/gxxx/selectAllDq#"  title="2020年拟在山东招生普通高校专业（类）选考科目要求" target="_blank">2020年拟在山东招生普通高校专业（类）选..
                </a>
            </dd>      
        </dl>
        <dl>
            <dt>
                <a href="NewsList.aspx?BCID=1&CID=16" target="_blank">友情链接
                </a>
            </dt>            
            <dd>
                <a href="http://www.sdzk.cn/"  title=">山东省招生教育考试院官方网站" target="_blank">山东省教育招生考试院官方网站
                </a>
            </dd>
            <dd>
                <a href="http://www.moe.gov.cn/"  title="中华人民共和国教育部官网" target="_blank">中华人民共和国教育部官方网站
                </a>
            </dd>
            <dd>
                <a href="http://edu.shandong.gov.cn/"  title="山东省教育厅官方网站" target="_blank">山东省教育厅官方网站</a>
            </dd>
            <dd>
                <a href="https://www.eol.cn/"  title="中国教育在线官方网站" target="_blank">中国教育在线官方网站
                </a>
            </dd>
            <dd>
                <a href="https://gaokao.chsi.com.cn/"  title="阳光高考官方网站" target="_blank">阳光高考官方网站
                </a>
            </dd>
        </dl>
    </div>
    <script type="text/javascript">
            //热点图轮播
            jQuery(".focusBox").slide({ mainCell: ".focuspic", effect: "left", autoPlay: true, delayTime: 300 });
            //要闻热点切换
            jQuery(".newsTab").slide();
            //中间校区向上翻滚
            jQuery(".picScroll-top").slide({ mainCell: ".bd ul", autoPage: true, effect: "topLoop", autoPlay: true, vis: 1, });
            //点击显示更多
            $("#mid_moreshow").click(function () { $("#mid_popshow").show(); })
            //点击关闭
            $('#mid_moreclose, .all').click(function () { $("#mid_popshow").hide(); })
            //底部校区左滚动
            jQuery(".picMarquee-left").slide({ mainCell: ".bd ul", autoPlay: true, effect: "leftMarquee", vis: 7, interTime: 50 });
            //点击显示更多
            $("#fot_moreshow").click(function () { $("#fot_popshow").show(); })
            //点击关闭
            $('#fot_moreclose, .all').click(function () { $("#fot_popshow").hide(); })
        </script> 
    </div>
    <div class="contain fot-txt">
         <div class="fotNav">
             <span style="display:block;padding-left:320px;padding-top: 20px">Copyright  &copy; 2020
                 <a id="pixinventLink" target="_blank" class="text-bold-800 primary darken-2">
                 济南凤鸣科技工作室
                 </a>
                 ,All rights reserved. 
             </span>   
        </div> 
    </div>
</form>
</div>
</body>
</html>
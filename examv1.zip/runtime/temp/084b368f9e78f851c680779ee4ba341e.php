<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"D:\webroot\examv1\public/../application/index\view\index\notice_add.html";i:1581649432;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="/public/static/css/style.css">
	<title>添加</title>
</head>
<body>
<div class="container">
	<div class="row clearfix">
		<div class="col-md-offset-3 col-md-6 column">
			<div class="content">
				<form method="post">
					<table class="table table-bordered text-center">
						<caption class="text-center">添加权威数据</caption>
						<tr>
							<td>
								标题<input type="text" name="notice_title" id="notice_title">
							</td>
						</tr>
						<tr>
							<td>
								网址<input type="text" name="notice_web" id="notice_web">
							</td>
						</tr>
						<tr>
							<td>
								日期<input type="text" name="notice_date" id="notice_date">
							</td>
						</tr>
						<tr>
							<td>
								<input type="submit" value="添加">
								<input type="button" value="返回" onclick="window.history.back()">
							</td>
						</tr>
					</table>
				</form>
			</div>
		</div>
		<div class="col-md-offset-3 col-md-6 column">

		</div>
	</div>
</div>
</body>
</html>

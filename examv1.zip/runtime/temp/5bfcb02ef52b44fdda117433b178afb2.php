<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:92:"D:\phpstudy_pro\WWW\webroot\examv1\public/../application/voluntary\view\index\voluntary.html";i:1584707445;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>
  山东省高考志愿辅助决策系统
    </title>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <link rel="stylesheet" href="/public/static/css/base.css" type="text/css" />
    <link href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.css">
</head>
<body>
    <div id="barrierfree_container">
        <form method="post" action="" id="form1">
            <div class="aspNetHidden">
            </div>
            <div class="aspNetHidden">
                <div class="top">
                    <div class="contain">
                        <p>欢迎使用山东省高考辅助决策系统！</p>
                        <div class="fr">
                            <a href="">登录</a>
                            <a href="">注册</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="contain topBanaer">
                <img src="../../../../public/static/img/logo.jpg">
                <ul class="topnav">
                    <li id="nav1" ><a href="<?php echo url('index/index/index'); ?>">网站首页</a></li>
                    <li id="nav2"><a href="<?php echo url('notice/index/notice'); ?>">通知公告</a></li>
                    <li id="nav3"><a href="<?php echo url('data/index/data'); ?>">权威数据</a></li>
                    <li id="nav4" ><a href="<?php echo url('major/index/major'); ?>">院校查询</a></li>
                    <li id="nav5"><a href="<?php echo url('major/index/major'); ?>">专业查询</a></li>
                    <li id="nav6" class="none on"><a href="<?php echo url('voluntary/index/voluntary'); ?>">模拟志愿</a></li>
                </ul>
            </div>
            <div class="container">
                <div class="row clearfix">
                    <div class="col-md-12 column">
                        <form class="form-horizontal" action="<?php echo url('index/voluntary'); ?>" method="post">
                            <div class="form-group">
                                <label for="major_name" class="col-sm-offset-2 col-sm-2 control-label">
                                     专业名称：
                                </label>
                                <div class="col-sm-2 col-md-pull-1 " style="margin-top: -5px">
                                    <input type="text" class="form-control" id="major_name" name="major_name" placeholder="请输入专业名称"  autocomplete="off">
                                </div>
                                <label for="major_level" class="col-sm-2 control-label">
                                    学科评估结果：
                                </label>
                                <div class="col-sm-2 col-md-pull-1" style="margin-top: -5px">
                                    <select name="major_level" id="major_level"class="form-control">
                                        <option value="全部">全部</option>
                                        <option value="A+">A+</option>
                                        <option value="A">A</option>
                                        <option value="A-">A-</option>
                                        <option value="B+">B+</option>
                                        <option value="B">B</option>
                                        <option value="B-">B-</option>
                                        <option value="C+">C+</option>
                                        <option value="C">C</option>
                                        <option value="C-">C-</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="university_name" class="col-sm-offset-2 col-sm-2 control-label" style="padding-top: 15px">院校名称：
                                </label>
                                <div class="col-sm-2 col-md-pull-1 " style="margin-top: 10px">
                                    <input type="text" class="form-control" id="university_name" name="university_name" placeholder="请输入院校名称"  autocomplete="off">
                                </div>
                                <label for="" class="col-sm-offset-0 col-sm-2 control-label" style="padding-top: 15px;padding-left: -30px">院校层次：
                                </label>
                                <div class="col-sm-2 col-md-pull-1" style="margin-top: 10px">
                                    <div class="radio">
                                        <label>
                                            <input type="radio" value="985" name="university_985" id="university_985">985
                                        </label>
                                        <label>
                                            <input type="radio" value="211" name="university_211" id="university_211">211
                                        </label>
                                        <label>
                                            <input type="radio" value="一流大学" name="first_class" id="first_class">一流大学
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="province" class="col-sm-offset-2 col-sm-2 control-label" style="margin-top: 15px">
                                    所在地区：
                                </label>
                                <div class="col-sm-2 col-md-pull-1 " style="margin-top: 10px">
                                    <select name="province" id="province"class="form-control">
                                        <option value="全部">－－省份－－</option>
                                        <option value="河北">河北</option>
                                        <option value="山西">山西</option>
                                        <option value="辽宁">辽宁</option>
                                        <option value="吉林">吉林</option>
                                        <option value="黑龙省">黑龙江</option>
                                        <option value="江苏">江苏</option>
                                        <option value="浙江">浙江</option>
                                        <option value="安徽">安徽</option>
                                        <option value="福建">福建</option>
                                        <option value="江西">江西</option>
                                        <option value="山东">山东</option>
                                        <option value="河南">河南</option>
                                        <option value="湖北">湖北</option>
                                        <option value="湖南">湖南</option>
                                        <option value="广东">广东</option>
                                        <option value="海南">海南</option>
                                        <option value="四川">四川</option>
                                        <option value="云南">云南</option>
                                        <option value="贵州">贵州</option>
                                        <option value="陕西">陕西</option>
                                        <option value="甘肃">甘肃</option>
                                        <option value="青海">青海</option>
                                        <option value="内蒙古自治区">内蒙古自治区</option>
                                        <option value="广西壮族自治区">广西壮族自治区</option>
                                        <option value="西藏自治区">西藏自治区</option>
                                        <option value="宁夏回族自治区">宁夏回族自治区</option>
                                        <option value="新建维吾尔自治区">新建维吾尔自治区</option>
                                        <option value="北京">北京</option>
                                        <option value="上海">上海</option>
                                        <option value="天津">天津</option>
                                        <option value="重庆">重庆</option>
                                    </select>
                                </div>
                                <label for="subject_limit" class="col-sm-2 control-label" style="margin-top: 15px">
                                    办学层次：
                                </label>
                                <div class="col-sm-4 col-md-pull-1" style="margin-top: 15px">
                                    <label>
                                        <input type="radio" name="university_level" id="university_level" value="本科" checked>本科
                                    </label>
                                    <label>
                                        <input type="radio" name="university_level" id="university_level" value="专科">专科
                                    </label>
                                </div>
                            </div>
                             <div class="form-group">
                            <label for="" class="col-sm-pull-4 col-sm-2 control-label" style="margin-top: 15px">
                                预估分数：
                            </label>
                            <div class="col-sm-1 col-md-pull-5 " style="margin-top: 8px">
                                <input type="text" class="form-control" id="score_min" name="score_min" placeholder="下限"autocomplete="off">
                            </div>
                            <div class="col-sm-1 col-md-pull-5 " style="margin-top: 8px; ">
                                 <input type="text" class="form-control" id="score_max" name="score_max" placeholder="上限" autocomplete="off" >
                            </div>
                            <label for="" class="col-md-pull-4 col-sm-2 control-label" style="margin-top: 15px">
                                预估位次：
                            </label>
                            <div class="col-sm-1 col-md-pull-3 " style="margin-top: -28px">
                                  <input type="text" class="form-control" id="pos_min" name="pos_min" placeholder="下限" autocomplete="off">
                            </div>
                            <div class="col-sm-1 col-md-pull-3 " style="margin-top: -28px">
                                  <input type="text" class="form-control" id="pos_max" name="pos_max" placeholder="上限"autocomplete="off">
                            </div>
                        </div>
                            <div class="form-group">
                                <div class="col-sm-offset-6 col-sm-4">
                                    <button type="submit" class="btn btn-default">查询</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="row clearfix" style="margin-top: 10px; padding-right: 35px width=90%">
                        <div class="col-md-12 column">
                            <div style="overflow: auto;">
                               <table class="table table-bordered table-hover table-condensed table-responsive">
                                    <tr>
                                        <th>院校代号</th>
                                        <th>院校名称</th>
                                        <th>院校类型</th>
                                        <th>专业名称</th>
                                        <th>2019录取最低分</th>
                                        <th>2018录取最低分</th>
                                        <th>2017录取最低分</th>
                                        <th>2019最低位次</th>
                                        <th>2018最低位次</th>
                                        <th>2017最低位次</th>
                                        <th>2019平均分</th>
                                        <th>2018平均分</th>
                                        <th>2017平均分</th>
                                        <th>专业类别</th>
                                        <th>学科评估</th>
                                        <th>选考科目要求</th>
                                        <th>省份</th>
                                        <th>城市</th>
                                        <th>主管部门</th>
                                        <th>办学层次</th>
                                        <th>排名</th>
                                        <th>985大学</th>
                                        <th>211大学</th>
                                        <th>一流大学建设高校</th>
                                        <th>一流大学类别</th>
                                        <th>一流学科建设高校</th>
                                        <th>一流学科</th>
                                        <th>备注</th>
                                        <th>学校官网</th>
                                        <th>招生章程</th>
                                        <th>操作</th>
                                    </tr>
                                    <?php if(is_array($voluntary) || $voluntary instanceof \think\Collection || $voluntary instanceof \think\Paginator): $i = 0; $__LIST__ = $voluntary;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$voluntary): $mod = ($i % 2 );++$i;?>
                                    <tr>
                                        <td><?php echo $voluntary['university_code']; ?></td>
                                        <td><?php echo $voluntary['university_name']; ?></td>
                                        <td><?php echo $voluntary['type']; ?></td>
                                        <td><?php echo $voluntary['major_name']; ?></td>
                                        <td><?php echo $voluntary['min2019']; ?></td>
                                        <td><?php echo $voluntary['min2018']; ?></td>
                                        <td><?php echo $voluntary['min2017']; ?></td>
                                        <td><?php echo $voluntary['pos2019']; ?></td>
                                        <td><?php echo $voluntary['pos2018']; ?></td>
                                        <td><?php echo $voluntary['pos2017']; ?></td>
                                        <td><?php echo $voluntary['ave2019']; ?></td>
                                        <td><?php echo $voluntary['ave2018']; ?></td>
                                        <td><?php echo $voluntary['ave2017']; ?></td>
                                        <td><?php echo $voluntary['major_type']; ?></td>
                                        <td><?php echo $voluntary['major_level']; ?></td>
                                        <td><?php echo $voluntary['subject_limit']; ?></td>
                                        <td><?php echo $voluntary['province']; ?></td>
                                        <td><?php echo $voluntary['city']; ?></td>
                                        <td><?php echo $voluntary['department']; ?></td>
                                        <td><?php echo $voluntary['university_level']; ?></td>
                                        <td><?php echo $voluntary['university_order']; ?></td>
                                        <td><?php echo $voluntary['university_985']; ?></td>
                                        <td><?php echo $voluntary['university_211']; ?></td>
                                        <td><?php echo $voluntary['first_class']; ?></td>
                                        <td><?php echo $voluntary['category']; ?></td>
                                        <td><?php echo $voluntary['first_university']; ?></td>
                                        <td><?php echo $voluntary['first_discipline']; ?></td>
                                        <td><?php echo $voluntary['comment']; ?></td>
                                        <td> <a href="<?php echo $voluntary['website']; ?>">访问</a></td>
                                        <td><a href="<?php echo $voluntary['charter']; ?>">访问</a></td>
                                        <td>收藏至预填表</td>
                                   </tr>
                                  <?php endforeach; endif; else: echo "" ;endif; ?>
                              </table>
                         </div>
                     </div>
                     <div class="col-md-12 column">
                         <div class="pagination pull-right">
                             <?php echo $voluntary->render(); ?>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     
     <div class="contain fot-txt">
         <div class="fotNav">
             <span style="display:block;padding-left:320px;padding-top: 20px">Copyright  &copy; 2020
                 <a id="pixinventLink" target="_blank" class="text-bold-800 primary darken-2">
                  济南凤鸣科技工作室
                 </a>
                  ,All rights reserved. 
             </span>   
         </div> 
     </div>
</form>
</div>
</body>
</html>

<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:66:"D:\webroot\examv1\public/../application/data\view\index\index.html";i:1583755403;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="../../favicon.ico" rel="icon">
    <title>山东省高考志愿辅助决策系统</title>
    <link rel="stylesheet" type="text/css" media="screen" href="https://cdn.staticfile.org/ionicons/2.0.1/css/ionicons.min.css">
    <link href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="../../../../public/static/css/dashboard.css" rel="stylesheet"> 
	  <style>
	    table td {word-break: keep-all;white-space:nowrap;}
	    table th {word-break: keep-all;white-space:nowrap;}
	  </style>
  </head>
  <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <a class="navbar-brand" href="#">凤鸣科技</a>
        </div>
        <div class="navbar-collapse collapse" id="navbar">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#">登录</a></li>
            <li><a href="#">注册</a></li>
            <li><a href="#">个人信息修改</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
						<li><a href="<?php echo url('notice/index/index'); ?>">通知公告</a></li>
						<li class="active"><a href="<?php echo url('data/index/index'); ?>">权威数据<span class="sr-only">(current)</span></a></li>
            <li><a href="<?php echo url('university/index/index'); ?>">院校库</a></li>
            <li><a href="<?php echo url('major/index/index'); ?>">专业库</a></li>
            <li><a href="<?php echo url('user/index/index'); ?>">用户表</a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">山东省高考志愿辅助决策系统</h1>
          <h3 class="sub-header">权威数据管理</h3>
          <div class="table-responsive" style="overflow: auto;">
          	<table class="table table-striped table table-bordered table-hover table-condensed table-responsive">
          		<tr>
          			<th>标题</th>
          			<th>网址</th>
          			<th>日期</th>
          			<th>操作</th>
          		</tr>
          		<?php if(is_array($datas) || $datas instanceof \think\Collection || $datas instanceof \think\Paginator): $i = 0; $__LIST__ = $datas;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$data): $mod = ($i % 2 );++$i;?>
          		<tr>
          			<td><?php echo $data['data_title']; ?></td>
          			<td><?php echo $data['data_web']; ?></td>
          			<td><?php echo $data['data_date']; ?></td>
          			<td>
          				<i class="icon ion-compose" style="color: green"></i>
          				<a href="<?php echo url('edit', ['data_id'=>$data['data_id']]); ?>" onclick="return confirm('确认修改这条数据吗？')">修改</a>
          				<i class="icon ion-trash-a" style="color: darkred"></i>
          				<a href="<?php echo url('delete', ['data_id'=>$data['data_id']]); ?>" onclick="return confirm('确认删除这条数据吗？')">删除</a>
          			</td>
          		</tr>
          		<?php endforeach; endif; else: echo "" ;endif; ?>
          	</table>
          </div>
          <div class="col-md-offset-3 col-md-6 text-right">
          	<i class="icon ion-plus-circled" style="color: green"></i>
          	<a href="<?php echo url('add'); ?>" onclick="return confirm('确认添加数据吗？')">添加</a>
          </div>
          <div class="col-md-offset-3 col-md-6 column">
          	<div class="pagination pull-right">
          		<?php echo $datas->render(); ?>
          	</div>
          </div>
        </div>
      </div>
    </div>
    <footer class="footer footer-static footer-light">
      <p class="clearfix text-muted text-center px-2">
        <span>Copyright  &copy; 2020
          <a id="pixinventLink" target="_blank" class="text-bold-800 primary darken-2">
					 济南凤鸣科技工作室
					</a>
					,All rights reserved. 
        </span>
      </p>
    </footer>
  </body>
</html>
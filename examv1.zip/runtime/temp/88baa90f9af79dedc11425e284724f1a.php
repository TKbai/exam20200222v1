<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:69:"D:\webroot\examv1\public/../application/notice\view\index\notice.html";i:1583751621;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="../../favicon.ico" rel="icon">
    <title>山东省高考志愿辅助决策系统</title>
    <link href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.css">
    <link href="../../../../public/static/css/justified-nav.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">
      <div class="masthead">
        <img src="../../../../public/static/img/banner.jpg" width="1137px" >
        <nav>
          <ul class="nav nav-justified">
            <li class="active"><a href="<?php echo url('notice/index/notice'); ?>">通知公告</a></li>
            <li><a href="<?php echo url('data/index/data'); ?>">权威数据</a></li>
            <li><a href="<?php echo url('university/index/university'); ?>">院校查询</a></li>
            <li><a href="<?php echo url('major/index/major'); ?>">专业查询</a></li>
            <li><a href="<?php echo url('mymajor/index/mymajor'); ?>">我收藏的专业</a></li>
            <li><a href="<?php echo url('myuniversity/index/myuniversity'); ?>">我收藏的院校</a></li>
          </ul>
        </nav>  
      </div>
      <div class="content" style="">
        <div class="row clearfix">
          <div class="col-md-12 column">
            <a href="http://edu.shandong.gov.cn/art/2020/1/9/art_114775_8634265.html">动漫视频：山东省2020年“新高考”问答</a></br>
            <a href="http://edu.shandong.gov.cn/art/2019/12/16/art_11992_8358324.html">山东省2020年高考政策30问</a></br>
            <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4590">山东省2020年普通高校招生考试录取政策和志愿填报百问百答（试用版）</a></br>
            <a href="http://xkkm.sdzk.cn/zy-manager-web/gxxx/selectAllDq#">2020年拟在山东招生普通高校专业（类）选考科目要求</a></br>
            <a href="http://gaokao.eol.cn/news/201906/t20190617_1664626.shtml">教育部：2019年全国高等学校名单</a></br>
            <a href=" http：//wsbm.sdzk.cn"> 山东高考报名系统入口</a></br>
            <a href="http://www.sdzk.cn/NewsInfo.aspx?NewsID=4722">近三年普通高考本科普通批首次志愿录取情况统计表</a>
          </div>
        </div>
      </div>
    </div>
    <div class="footer">
      <div class="row clearfix">
        <div class="col-md-12 column">
          <footer>
            <p style="text-align: center;">Copyright © 2020 济南凤鸣科技工作室</p>
          </footer>
        </div>
      </div>
    </div>
  </body>
</html>  
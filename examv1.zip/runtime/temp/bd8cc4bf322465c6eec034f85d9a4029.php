<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:65:"D:\webroot\examv1\public/../application/user\view\index\user.html";i:1583568591;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <link rel="stylesheet" href="/public/static/css/style.css">
        <title>登&nbsp;&nbsp;录</title>
    </head>
    <body>
        <div id="container">
            <div id="header"></div>
            <div id="nav"></div>
            <div id="content">
                <form method="post">
                    <table class="table table-bordered table-hover table-condensed table-responsive">
                        <caption style="text-align: center; margin-bottom: 10px;">登　录</caption>
                        <tr>
                            <td>标题</td>
                            <td><input type="text" name="data_title" id="data_title"></td>
                        </tr>
                        <tr>
                            <td>网址</td>
                            <td><input type="text" name="data_web" id="data_web"></td>
                        </tr>
                        <tr>
                            <td>日期</td>
                            <td><input type="text" name="data_date" id="data_date"></td>
                        </tr>
                        <tr>
                            <td>
                                验证码：
                            </td>
                            <td>
                                <input type="text" name="captcha" id="captcha">
                                <img name="verify_img" id="verify_img" src="<?php echo captcha_src(); ?>" alt="验证码"> <!-- 以图片形式调用验证码 -->
                                <a href="javascript:showcode()">看不清，换一张</a> <!-- 点击时触发javascript函数 -->
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="center">
                                <input type="submit" value="登录">&nbsp;&nbsp;
                            </td>
                        </tr>
                    </table>
                    <div style="text-align: center; padding-top: 5px; color: red; font-size: 18px;">
                        <?php echo $error; ?> <!-- 显示验证结果的错误信息 -->
                    </div>
                </form>
            </div>
            <div id="footer">
                <span>Copyright  &copy; 2020
                    <a id="pixinventLink" target="_blank" class="text-bold-800 primary darken-2">
                        济南凤鸣科技工作室
                    </a>
                    ,All rights reserved. 
                </span>
            </div>
        </div>
        <script>
            function showcode() {
                var img = document.getElementById('verify_img');
                img.src = "<?php echo captcha_src(); ?>?id=" + new Date(); //增加一个随机参数，防止图片缓存
                return false; //阻止超链接的跳转动作
            }
        </script>
    </body>
</html>

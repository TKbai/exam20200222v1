<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"D:\phpstudy_pro\WWW\webroot\examv1\public/../application/user\view\index\register.html";i:1584617966;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>山东省高考志愿辅助决策系统</title>
	<link rel="stylesheet" type="text/css" href="/public/static/css/register-login.css">
</head>
    <body>
        <div id="box"></div>
        <div class="cent-box register-box">
	        <div class="cent-box-header"  style="margin-top: -100px;">
		        <h1 class="main-title hide"></h1>
		        <h2 class="sub-title">山东省高考志愿辅助决策系统</h2>
	        </div>
	        <div class="cont-main clearfix">
		        <div class="index-tab"  style="margin-top: -20px;">
			        <div class="index-slide-nav">
				        <a href="login.html">登录</a>
				        <a href="register.html" class="active">注册</a>
				        <div class="slide-bar slide-bar1"></div>				
			        </div>
		        </div>
		        <div class="login form" style="margin-top: -10px;">
                    <form method="post">
			            <div class="group">
                            <div class="group-ipt user">
                                <input type="text" name="username" id="username" class="ipt" placeholder="输入用户账号" autocomplete="off" required>
                            </div>
                            <div class="group-ipt password">
                                <input type="text" name="password" id="password" class="ipt" placeholder="设置登录密码" autocomplete="off" required>
                            </div>
                            <div class="group-ipt user">
                                <input type="text" name="truename" id="truename" class="ipt" placeholder="输入真实姓名" autocomplete="off" required>
                            </div>
			                <div class="group-ipt email">
					            <input type="text" name="email" id="email" class="ipt" placeholder="输入用户邮箱" autocomplete="off" required>
				            </div>
				            <div class="group-ipt user">
					            <input type="text" name="phone" id="phone" class="ipt" placeholder="输入用户手机" autocomplete="off" required>
				            </div>
				            <div class="group-ipt user">
					            <input type="text" name="score" id="score" class="ipt" placeholder="输入预估总分数" autocomplete="off" required>
				            </div>
				            <div class="group-ipt user">
				                <input type="text" name="subjects" id="subjects" class="ipt" placeholder="输入选考科目" autocomplete="off" required>
				            </div>
				            <div class="group-ipt verify">
					            <input type="text" name="captcha" id="captcha" class="ipt" placeholder="输入验证码" autocomplete="off" required>
					            <img name="verify_img" id="verify_img" src="<?php echo captcha_src(); ?>" alt="验证码">
					            <a href="javascript:showcode()">看不清，换一张</a>
					        </div>  
			            </div>
                        <div class="button">
                            <input type="submit" class="login-btn register-btn" id="button" onclick="return confirm('确认注册吗？')" value="注册">
                        </div>
                    </form>
		        </div>
	        </div>
        </div>
        <div class="footer">
	        <span>Copyright  &copy; 2020
                <a id="pixinventLink" target="_blank" class="text-bold-800 primary darken-2">
                    济南凤鸣科技工作室
                </a>
                ,All rights reserved. 
            </span>
        </div>
        <script src='/public/static/js/particles.js' type="text/javascript"></script>
        <script src='/public/static/js/background.js' type="text/javascript"></script>
        <script>
            function showcode()
            {
            var img = document.getElementById('verify_img');
            img.src = "<?php echo captcha_src(); ?>?id="+new Date(); //增加一个随机参数，防止图片缓存
            return false; //阻止超链接的跳转动作
            }
        </script>
     </body>
</html>
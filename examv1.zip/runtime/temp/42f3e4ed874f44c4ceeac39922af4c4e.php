<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"D:\webroot\examv1\public/../application/university\view\index\university.html";i:1583751244;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN"><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <meta name="description" content="">
    <meta name="author" content="">
    <style>
      table td{word-break: keep-all;white-space:nowrap;}
      table th{word-break: keep-all;white-space:nowrap;}
    </style>
    <link href="../../favicon.ico" rel="icon">
    <title>山东省高考志愿辅助决策系统</title>
    <link href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.staticfile.org/font-awesome/4.7.0/css/font-awesome.css">
    <link href="../../../../public/static/css/justified-nav.css" rel="stylesheet">
  </head>
  <body>
    <div class="container">
      <div class="masthead">
        <img src="../../../../public/static/img/banner.jpg" " class="img-responsive center-block">
        <nav>
          <ul class="nav nav-justified">
            <li><a href="<?php echo url('notice/index/notice'); ?>">通知公告</a></li>
            <li><a href="<?php echo url('data/index/data'); ?>">权威数据</a></li>
            <li class="active"><a href="<?php echo url('university/index/university'); ?>">院校查询</a></li>
            <li><a href="<?php echo url('major/index/major'); ?>">专业查询</a></li>
            <li><a href="<?php echo url('mymajor/index/mymajor'); ?>">我收藏的专业</a></li>
            <li><a href="<?php echo url('myuniversity/index/myuniversity'); ?>">我收藏的院校</a></li>
          </ul>
        </nav>
        <div class="container">
          <div class="row clearfix">
            <div class="col-md-12 column">
              <h3 class="col-sm-offset-6">院校查询</h3>
              <form class="form-horizontal" action="<?php echo url('index/university'); ?>" method="post">
                <div class="form-group">
                  <label for="university_name" class="col-sm-offset-2 col-sm-2 control-label">
                    院校名称：
                  </label>
                  <div class="col-sm-2">
                    <input type="text" class="form-control" id="university_name" name="university_name" placeholder="请输入院校名字"
                      autocomplete="off">
                  </div>
                  <label for="type" class="col-sm-2 control-label">
                    院校类型：
                  </label>
                  <div class="col-sm-2">
                    <select name="type" id="type" class="form-control">
                      <option value="全部">全部</option>
                      <option value="综合">综合</option>
                      <option value="工科">工科</option>
                      <option value="农业">农业</option>
                      <option value="林业">林业</option>
                      <option value="医药">医药</option>
                      <option value="师范">师范</option>
                      <option value="语言">语言</option>
                      <option value="财经">财经</option>
                      <option value="政法">政法</option>
                      <option value="体育">体育</option>
                      <option value="艺术">艺术</option>
                      <option value="民族">民族</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label for="university_level" class="col-sm-offset-2 col-sm-2 control-label">办学层次：</label>
                  <div class="col-sm-2">
                    <div class="radio">
                      <label>
                        <input type="radio" name="university_level" id="university_level" value="本科" checked>本科
                      </label>
                      <label>
                        <input type="radio" name="university_level" id="university_level" value="专科">专科
                      </label>
                    </div>
                  </div>
                  <label for="university1" class="col-sm-2 control-label">
                    院校层次：
                  </label>
                  <div class="col-sm-4">
                    <div class="radio">
                      <label>
                        <input type="radio" value="1" name="level" id="level">985
                      </label>
                      <label>
                        <input type="radio" value="2" name="level" id="level">211
                      </label>
                      <label>
                        <input type="radio" value="3" name="level" id="level">一流大学
                      </label>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <div class="col-sm-offset-6 col-sm-4">
                    <button type="submit" class="btn btn-default">查询</button>
                  </div>
                </div>
              </form>
            </div>
            <div class="row clearfix" style="margin-top: 10px; padding-right: 35px">
              <div class="col-md-12 column">
                <div style="overflow: auto;">
                  <table class="table table-bordered table-hover table-condensed table-responsive">
                    <tr>
                      <th>院校名称</th>
                      <th>省份</th>
                      <th>城市</th>
                      <th>主管部门</th>
                      <th>办学层次</th>
                      <th>排名</th>
                      <th>985大学</th>
                      <th>211大学</th>
                      <th>一流大学建设高校</th>
                      <th>学校官网</th>
                      <th>招生章程</th>
                      <th>备注</th>
                    </tr>
                    <?php if(is_array($universities) || $universities instanceof \think\Collection || $universities instanceof \think\Paginator): $i = 0; $__LIST__ = $universities;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$university): $mod = ($i % 2 );++$i;?>
                    <tr>
                      <td><?php echo $university['university_name']; ?></td>
                      <td><?php echo $university['province']; ?></td>
                      <td><?php echo $university['city']; ?></td>
                      <td><?php echo $university['department']; ?></td>
                      <td><?php echo $university['university_level']; ?></td>
                      <td><?php echo $university['university_order']; ?></td>
                      <td>
                        <?php if($university['university_985'] == 1): ?>
                         <i class="fa fa-check" style="color: green"></i>
                        <?php endif; ?>
                      </td>
                      <td><?php if($university['university_211'] == 1): ?><i class="fa fa-check" style="color: green" ><?php endif; ?></td>
                      <td><?php if($university['first_class'] == 1): ?><i class="fa fa-check" style="color: green"></i><?php endif; ?></td>
                      <td>
                        <a href="<?php echo $university['website']; ?>">访问</a>
                      </td>
                      <td>
                        <a href="<?php echo $university['charter']; ?>">访问</a>
                      </td>
                      <td><?php echo $university['comment']; ?></td>
                    </tr>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                  </table>
                </div>
              </div>
              <div class="col-md-12 column">
                <div class="pagination pull-right">
                  <?php echo $universities->render(); ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer class="footer footer-static footer-light">
        <p class="clearfix text-muted text-center px-2">
          <span>Copyright  &copy; 2020
            <a id="pixinventLink" target="_blank" class="text-bold-800 primary darken-2">
      			 济南凤鸣科技工作室
      			</a>
      			,All rights reserved. 
          </span>
        </p>
      </footer>
    </div>      
  </body>
</html>
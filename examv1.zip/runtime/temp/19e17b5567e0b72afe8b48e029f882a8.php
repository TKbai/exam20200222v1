<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:64:"D:\webroot\examv1\public/../application/user\view\index\add.html";i:1583745611;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="../../favicon.ico" rel="icon">
    <title>山东省高考志愿辅助决策系统</title>
    <link href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link href="../../assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="../../../../public/static/css/dashboard.css" rel="stylesheet"> 
	<style>
	  table td {word-break: keep-all;white-space:nowrap;}
	  table th {word-break: keep-all;white-space:nowrap;}
	</style>
  </head>
  <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <a class="navbar-brand" href="#">凤鸣科技</a>
        </div>
        <div class="navbar-collapse collapse" id="navbar">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#">登录</a></li>
            <li><a href="#">注册</a></li>
            <li><a href="#">个人信息修改</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
			<li><a href="<?php echo url('notice/index/index'); ?>">通知公告</a></li>
			<li><a href="<?php echo url('data/index/index'); ?>">权威数据</a></li>
            <li><a href="<?php echo url('university/index/index'); ?>">院校库</a></li>
            <li><a href="<?php echo url('major/index/index'); ?>">专业库</a></li>
            <li class="active"><a href="<?php echo url('user/index/index'); ?>">用户表<span class="sr-only">(current)</span></a></li>
          </ul>
        </div>
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h1 class="page-header">山东省高考志愿辅助决策系统</h1>
          <h3 class="sub-header">用户信息管理</h3>
          <div class="container">
            <div class="row clearfix">
              <div class="col-md-offset-3 col-md-6 column">
                <div class="content">
                  <form method="post">
                    <table class="table table-bordered text-center">
                      <caption class="text-center">添加用户信息</caption>
                      <tr>
                        <td>用户账号</td>
                        <td><input type="text" name="username" id="username"></td>
                      </tr>
                      <tr>
                        <td>用户密码</td>
                        <td><input type="text" name="password" id="password"></td>
                      </tr>
                      <tr>
                        <td>真实姓名</td>
                        <td><input type="text" name="truename" id="truename"></td>
                      </tr>
                      <tr>
                        <td>用户邮箱</td>
                        <td><input type="text" name="email" id="email"></td>
                      </tr>
                      <tr>
                        <td>用户手机</td>
                        <td><input type="text" name="phone" id="phone"></td>
                      </tr>
                      <tr>
                        <td>预估总分数</td>
                        <td><input type="text" name="score" id="score"></td>
                      </tr>
                      <tr>
                        <td>选考科目</td>
                        <td><input type="text" name="subjects" id="subjects"></td>
                      </tr>
                    </table>
                    <div style="text-align: center">
                      <input type="submit" value="添加">
                      <input type="button" value="返回" onclick="window.history.back()">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-offset-3 col-md-6 text-right">
          	<i class="fa fa-plus" style="color: green"></i>
          	<a href="<?php echo url('add'); ?>" onclick="return confirm('确认添加吗？')">添加</a>
          </div>
        </div>
      </div>
    </div>
    <footer class="footer footer-static footer-light">
      <p class="clearfix text-muted text-center px-2">
        <span>Copyright  &copy; 2020
          <a id="pixinventLink" target="_blank" class="text-bold-800 primary darken-2">
					 济南凤鸣科技工作室
					</a>
					,All rights reserved. 
        </span>
      </p>
    </footer>
  </body>
</html>
<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:69:"D:\webroot\examv1\public/../application/voluntary\view\index\add.html";i:1581733682;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>山东省高考志愿辅助决策系统</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="/public/static/css/style.css">
	<style>
	  td:nth-child(1) {text-align: right;
	  } /* 第一列文字右对齐 */
	  td:nth-child(2) {text-align: left;
	  } /* 第一列文字左对齐 */
	  caption {font-size: 18.75px;
	  }
	</style>
  </head>
  <body>
    <div class="container">
      <div class="row clearfix">
        <div class="col-md-12 column">
        </div>
      </div>
      <div class="row clearfix">
        <div class="col-md-12 column">
		  <ul class="nav nav-tabs">
		    <li class="active"><a href="<?php echo url('notice/index/index'); ?>">通知公告</a></li>
			<li><a href="<?php echo url('add/index/index'); ?>">权威数据</a></li>
			<li><a href="#">院校库</a></li>
			<li><a href="#">专业库</a></li>
			<li><a href="#">填志愿</a></li>
		  </ul>
        </div>
      </div>
      <div class="row clearfix">
        <div class="col-md-offset-3 col-md-6 column">
      	  <div class="content">
      	    <form method="post">
      		  <table class="table table-bordered text-center">
      		    <caption class="text-center">添加通知公告</caption>
      			<tr>
      			  <td>标题</td>
				  <td><input type="text" name="notice_title" id="notice_title"></td>
      			</tr>
      			<tr>
      			  <td>网址</td>
      			  <td><input type="text" name="notice_web" id="notice_web"></td>
      			</tr>
      			<tr>
      			  <td>日期</td>
      			  <td><input type="text" name="notice_date" id="notice_date"></td>
      			</tr>	
      		  </table>
		      <div style="text-align: center">
			    <input type="submit" value="添加">
			    <input type="button" value="返回" onclick="window.history.back()">
			  </div>
      		</form>
      	  </div>
      	</div>
      </div>
      <div class="row clearfix">
        <div class="col-md-12 column">
        </div>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
  </body>
</html>
<?php
/**
 * 文件名：index.php
 * 描述：控制器
 * 作者：刘增昆
 * 日期：2020年2月14日
 * 版本号：V1.0
 * 版权：济南凤鸣科技有限公司
 * 修改人：
 * 修改日期：
 * 修改原因：
 */
namespace app\major\controller;

use think\Controller;
use think\Db;
use think\Request;

/**
 * Class Index
 * @package app\major\controller
 */
class Index extends Controller
{
    public function index()
    {
        $majors = Db::table('exam_major')->where('state',1)->paginate(10);
        $this->assign("majors", $majors);
        return $this->fetch();
    }

    /**
     * 添加专业
     * @return mixed
     */
    public function add()
    {
        if (Request::instance()->isPost()) {
            $major = Request::instance()->param(); 
            $result = Db::table('exam_major')->insert($major);
            if ($result == true) {
                $this->success('添加成功！', url('index'), '', 1);
            } else {
                $this->error('添加失败！', '', '', 1);
            }
        } else {
            return $this->fetch();
        }
    }

    /**
     * 修改专业
     */
    public function edit()
    {
        $majorId = Request::instance()->param('major_id'); //读取专业
        if (Request::instance()->isPost()) {
            $major = Request::instance()->param(); //更改专业
            $result = Db::table('exam_major')->where('major_id', $majorId)->update($major);
            if ($result == true) {
                $this->success('修改成功！', url('index'), '', 1);
                return;
            } else {
                $this->error('修改失败！', '', '', 1);
            }
        } else {
            $majorInfo = Db::table('exam_major')->where('major_id', $majorId)->find();
            $this->assign('major', $majorInfo);
            return $this->fetch();
        }
    }

    /*
     * 删除专业
     */
    public function delete()
    {
        $majorId = Request::instance()->param('major_id');
        $major = array(
            'state' => 0,
        );
        $result = Db::table('exam_major')->where('major_id', $majorId)->update($major);
        if ($result == true) {
            $this->success('删除成功！', url('index'), '', 1);
            return;
        } else {
            $this->error('删除失败！', '', '', 1);
        }
    }

    /*
     * 查询专业
     */
    public function major()
    {
        $major_name = input('major_name');
        $major_level = input('major_level');
        $major_type = input('major_type');
        $first_discipline = input('first_discipline');
        $university_name = input('university_name');
        $min2019 = input('min2019');
        $pos2019 = input('pos2019');
        $score_min = input('score_min');
        $score_max = input('score_max');
        $pos_min = input('pos_min');
        $pos_max = input('pos_max');
        $config = ['query'=>[]];
        $config['query'] ['major_name'] = $major_name;
        $config['query'] ['major_level'] = $major_level;
        $config['query'] ['major_type'] = $major_type;
        $config['query'] ['first_discipline'] = $first_discipline;
        $config['query'] ['university_name'] = $university_name;
        $config['query'] ['min2019'] = $min2019;
        $config['query'] ['pos2019'] = $pos2019;
        $config['query'] ['score_min'] = $score_min;
        $config['query'] ['score_max'] = $score_max;
        $config['query'] ['pos_min'] = $pos_min;
        $config['query'] ['pos_max'] = $pos_max;
        if ($major_level == "全部") {
            if ($major_type == "全部") {
                $majors = Db::table('exam_major')
                              ->where('major_name', 'like', "%$major_name%")
                              ->where('first_discipline', '=', "$first_discipline")
                              ->where('university_name', 'like', "%$university_name%")
                              ->where('min2019','between',["$score_min", "$score_max"])
                              ->where('pos2019','between',["$pos_min", "$pos_max"])
                              ->where('state', 1)
                              ->paginate(10, false, $config);
            } else {
                $majors = Db::table('exam_major')
                              ->where('major_name', 'like', "%$major_name%")
                              ->where('major_type', '=', "$major_type")
                              ->where('first_discipline', '=', "$first_discipline")
                              ->where('university_name', 'like', "%$university_name%")
                              ->where('min2019','between',["$score_min", "$score_max"])
                              ->where('pos2019','between',["$pos_min", "$pos_max"])
                              ->where('state', 1)
                              ->paginate(10, false, $config);
            }
        } else {
            if ($major_type == "全部") {
                $majors = Db::table('exam_major')
                              ->where('major_name', 'like', "%$major_name%")
                              ->where('major_level', 'like', "%$major_level%")
                              ->where('first_discipline', '=', "$first_discipline")
                              ->where('university_name', 'like', "%$university_name%")
                              ->where('min2019','between',["$score_min", "$score_max"])
                              ->where('pos2019','between',["$pos_min", "$pos_max"])
                              ->where('state', 1)
                              ->paginate(10, false, $config);
            } else {
                $majors = Db::table('exam_major')
                              ->where('major_name', 'like', "%$major_name%")
                              ->where('major_level', 'like', "%$major_level%")
                              ->where('major_type', '=', "$major_type")
                              ->where('first_discipline', '=', "$first_discipline")
                              ->where('university_name', 'like', "%$university_name%")
                              ->where('min2019','between',["$score_min", "$score_max"])
                              ->where('pos2019','between',["$pos_min", "$pos_max"])
                              ->where('state', 1)
                              ->paginate(10, false, $config);
            }
        }
        $this->assign('majors', $majors);
        return $this->fetch();
    }
}
<?php
/**
 * 文件名：index.php
 * 描述：控制器
 * 作者：刘增昆
 * 日期：2020年2月14日
 * 版本号：V1.0
 * 版权：济南凤鸣科技有限公司
 * 修改人：
 * 修改日期：
 * 修改原因：
 */
namespace app\data\controller;

use think\Controller;
use think\Db;
use think\Request;

/**
 * Class Index
 * @package app\data\controller
 */
class Index extends Controller
{
    public function data()
    {
    	return $this->fetch();
    }
    
		public function index()
		{
			$datas = Db::table('exam_data')->where('state',1)->paginate(10);
			$this->assign("datas", $datas);
			return $this->fetch();
		}
	
			/**
			* 添加数据
			* @return mixed
			*/
		public function add()
		{
				if (Request::instance()->isPost()) {
						$data = Request::instance()->param(); //添加数据
						if ($data['data_date'] == '') {
						$data['data_date'] = null;
						}
						$result = Db::table('exam_data')
													->insert($data);
						if ($result == true) {
							$this->success('添加成功！', url('index'), '', 1);
						} else {
							$this->error('添加失败！', '', '', 1);
						}
				} else {
					return $this->fetch();
				}
		}

    /**
     * 修改数据
     * @return mixed|void
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \think\exception\PDOException
     */
    public function edit()
    {
        $dataId = Request::instance()->param('data_id'); //读取数据
        if (Request::instance()->isPost()) {
            $data = Request::instance()->param(); //更改数据
						if ($data['data_date'] == '') {
						$data['data_date'] = null;
						}
            $result = Db::table('exam_data')
													->where('data_id', $dataId)
													->update($data);
            if ($result == true) {
                $this->success('修改成功！', url('index'), '', 1);
                return;
            } else {
                $this->error('修改失败！', '', '', 1);
						}
        } else {
            $dataInfo = Db::table('exam_data')->where('data_id', $dataId)->find();
            $this->assign('data', $dataInfo);
            return $this->fetch();
				}
    }

    /**
     * 删除数据
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     */
    public function delete()
    {
        $dataId = Request::instance()->param('data_id');
        $data = array(
            'state' => 0,
        );
        $result = Db::table('exam_data')->where('data_id', $dataId)->update($data);
        if ($result == true) {
            $this->success('删除成功！', url('index'), '', 1);
            return;
        } else {
            $this->error('删除失败！', '', '', 1);
				}
    }
}	

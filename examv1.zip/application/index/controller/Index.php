<?php
namespace app\Index\controller;

use think\Controller;
use think\Db;
use think\Request;

class Index extends Controller
{
    public function Index()
    {
        return $this->fetch();
    }
}

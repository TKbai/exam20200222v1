<?php
/**
 * 文件名：index.php
 * 描述：控制器
 * 作者：刘增昆
 * 日期：2020年3月17日
 * 版本号：V1.0
 * 版权：济南凤鸣科技工作室
 * 修改人：
 * 修改日期：
 * 修改原因：
 */
namespace app\user\controller;

use think\Controller;
use think\Db;
use think\Request;
use think\Validate;
use think\Session;

class Index extends Controller
{	
    /*
     *
     */
    public function index()
    {
        $users = Db::table('exam_user')->where('state',1)->paginate(10);
        $this->assign("users", $users);
        return $this->fetch();
    }
    
    /**
     * 添加专业
     * @return mixed
     */
    public function register()
    {
        if (Request::instance()->isPost()) {
            $username = Request::instance()->param('username'); 
            $password = Request::instance()->param('password'); 
            $truename = Request::instance()->param('truename'); 
            $email = Request::instance()->param('email'); 
            $phone = Request::instance()->param('phone'); 
            $score = Request::instance()->param('score');
            $subjects = Request::instance()->param('subjects'); 
            $user = array(
            'username' => $username,
            'password' => md5($password),
            'truename' => $truename,
            'email' => $email,
            'phone' => $phone,
            'score' => $score,
            'subjects' => $subjects,
            );
            $captcha = input('post.captcha');  
            $rule = [ //验证规则
                'username' => 'require|length:5,16',
                'password' => 'require|length:6,32',
                'captcha'  => 'require|captcha',
            ];
            
            $msg = [ //提示内容
                'username.require' => '用户名必须',
                'username.length'  => '用户名为5-16位',
                'password.require' => '密码必须',
                'password.length'  => '密码为6-32位',
                'captcha.require'  => '验证码必须',
                'captcha'          => '验证码格式错误',
            ];
            
            $data = [ //需要验证的值
                'username' => $username,
                'password' => $password,
                'captcha'  => $captcha,
            ]; 
                
            $validate = new Validate($rule, $msg); //实例化验证类
            $result = $validate->check($data); //进行验证
            //从数据库读取数据进行用户名验证
            $admin_info = DB::name('exam_user')
            ->where('username',$username)
            ->find(); 
            if(!empty($admin_info)){
                $this->error('用户名已存在，请重新注册',url('user/index/register'));
            } else {
                if ($result == true) { //如果验证成功则进行登录操作
                    $result = Db::table('exam_user')->insert($user);
                    if ($result == true) {
                         $this->success('添加成功！', url('index'), '', 1);
                    } else {
                    $this->error('添加失败！', '', '', 1);
                    }
                } else { //否返回错误信息到界面
                    $error = $validate->getError();
                    $this->assign('error',$error);
                    return $this->fetch();
                }
            }
        } else {
            return $this->fetch();
        }
        $error = ''; //赋初值
        $this->assign('error',$error);
//      return $this->fetch();
    }
    
    /**
     * 修改专业
     */
    public function edit()
    {
        $userId = Request::instance()->param('user_id'); //读取专业
        if (Request::instance()->isPost()) {
            $user = Request::instance()->param(); //更改专业
            $result = Db::table('exam_user')->where('user_id', $userId)->update($user);
            if ($result == true) {
                $this->success('修改成功！', url('index'), '', 1);
                return;
            } else {
                $this->error('修改失败！', '', '', 1);
            }
        } else {
            $userInfo = Db::table('exam_user')->where('user_id', $userId)->find();
            $this->assign('user', $userInfo);
            return $this->fetch();
        }
    }
    
    /*
     * 删除专业
     */
    public function delete()
    {
        $userId = Request::instance()->param('user_id');
        $user = array(
            'state' => 0,
        );
        $result = Db::table('exam_user')->where('user_id', $userId)->update($user);
        if ($result == true) {
            $this->success('删除成功！', url('index'), '', 1);
            return;
        } else {
            $this->error('删除失败！', '', '', 1);
        }
    }

    /*
     * 
     */
    public function login()
    {
        if (input('post.')) {
            $username = input('post.username');
            $password = input('post.password');
            $captcha = input('post.captcha');  
            $rule = [ //验证规则
                'username'  => 'require|length:5,16',
                'password'   => 'require|length:6,32',
                'captcha' => 'require|captcha',
            ];
      
            $msg = [ //提示内容
                'username.require' => '用户名必须',
                'username.length'  => '用户名为5-16位',
                'password.require' => '密码必须',
                'password.length'  => '密码为6-32位',
                'captcha.require' => '验证码必须',
                'captcha'        => '验证码格式错误',
            ];
      
            $data = [ //需要验证的值
                'username'  => $username,
                'password'   => $password,
                'captcha' => $captcha,
            ];
                   
            $validate = new Validate($rule, $msg); //实例化验证类
            $result = $validate->check($data); //进行验证
            if ($result == true) { //如果验证成功则进行登录操作
                $password = input('post.password'); //密码加密
                $result = Db::table('exam_user')->where('username',$username)->value('username'); //用户名验证                            
                $results = Db::table('exam_user')->where('username',$username)->value('password');
                if ($results == md5($password) & $result == $username) {
                    Session::set('username',$username);
                    $this->success('登录成功！', url('index/index/index'));
                } else {
                    $this->error('登录失败！');
                }
            } else { //否返回错误信息到界面
                $error = $validate->getError();
                $this->assign('error',$error);
                return $this->fetch();
            }
        }
        $error = ''; //赋初值
        $this->assign('error',$error);
        return $this->fetch();
    }
    
     public function logout(){//登出
        session(null);//退出清空session
        return $this->success('退出成功',url('user/index/login'));//跳转到登录页面
    }

    
    
}

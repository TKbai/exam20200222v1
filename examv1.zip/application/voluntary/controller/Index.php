<?php
/**
 * 文件名：index.php
 * 描述：志愿表控制器
 * 作者：刘增昆
 * 日期：2020年2月14日
 * 版本号：V1.0
 * 版权：济南凤鸣科技有限公司
 * 修改人：
 * 修改日期：
 * 修改原因：
 */
namespace app\voluntary\controller;

use think\Controller;
use think\Db;
use think\Request;

class Index extends Controller
{
    public function index()
    {
        $voluntary = Db::table('exam_voluntary')->where('state',1)->paginate(10);
        $this->assign("voluntary", $voluntary);
        return $this->fetch();
    }

    /**
     * 添加志愿
     * @return mixed
     */
    public function add()
    {
        if (Request::instance()->isPost()) {
            $voluntary = Request::instance()->param();
            $result = Db::table('exam_voluntary')->insert($voluntary);
            echo $result;
            exit;
            if ($result == true) {
                $this->success('添加成功！', url('index'), '', 1);
            } else {
                $this->error('添加失败！', '', '', 1);
            }
        } else {
            return $this->fetch();
        }
    }

    /**
     * 修改志愿
     * @return mixed|void
     * @throws \think\Exception
     * @throws \think\db\exception\voluntaryNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \think\exception\PDOException
     */
    public function edit()
    {
        $voluntaryId = Request::instance()->param('voluntary_id');
        if (Request::instance()->isPost()) {
            $voluntary = Request::instance()->param();
            $result = Db::table('exam_voluntary')->where('voluntary_id', $voluntaryId)->update($voluntary);
            if ($result == true) {
                $this->success('修改成功！', url('index'), '', 1);
                return;
            } else {
                $this->error('修改失败！', '', '', 1);
            }
        } else {
            $voluntaryInfo = Db::table('exam_voluntary')->where('voluntary_id', $voluntaryId)->find();
            $this->assign('voluntary', $voluntaryInfo);
            return $this->fetch();
        }
    }

    /**
     * 删除志愿
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     */
    public function delete()
    {
        $voluntaryId = Request::instance()->param('voluntaryId');
        $voluntary = array(
            'state' => 0,
        );
        $result = Db::table('exam_voluntary')->where('voluntary_id', $voluntaryId)->update($voluntary);
        if ($result == true) {
            $this->success('删除成功！', url('index'), '', 1);
            return;
        } else {
            $this->error('删除失败！', '', '', 1);
        }
    }

    public function voluntary()
    {
        $major_name = input('major_name');
        $major_level = input('major_level');
        $university_name = input('university_name');
        $province = input('province');
        $university_level = input('university_level');
        $level = input('level');
        $min2019 = input('min2019');
        $pos2019 = input('pos2019');
        $score_min = input('score_min');
        $score_max = input('score_max');
        $pos_min = input('pos_min');
        $pos_max = input('pos_max');
        $config = ['query'=>[]];
        $config['query'] ['major_name'] = $major_name;
        $config['query'] ['major_level'] = $major_level;
        $config['query'] ['university_name'] = $university_name;
        $config['query'] ['province'] = $province;
        $config['query'] ['university_level'] = $university_level;
        $config['query'] ['min2019'] = $min2019;
        $config['query'] ['pos2019'] = $pos2019;
        $config['query'] ['score_min'] = $score_min;
        $config['query'] ['score_max'] = $score_max;
        $config['query'] ['pos_min'] = $pos_min;
        $config['query'] ['pos_max'] = $pos_max;
        ($level == 1) ? $config['query'] ['level'] = 1 : '';
        ($level == 2) ? $config['query'] ['level'] = 2 : '';
        ($level == 3) ? $config['query'] ['level'] = 3 : '';
        ($level == 1) ? $where985 = ['university_985' => 1] : $where985=[];
        ($level == 2) ? $where211 = ['university_211' => 1] : $where211=[];
        ($level == 3) ? $wherefc = ['first_class' => 1] : $wherefc=[];
        if ($major_level == "全部") {
            if ($province == "全部") {
                $voluntary = Db::table('exam_major_university')
                                 ->where('major_name', 'like', "%$major_name%")
                                 ->where('university_name', 'like', "%$university_name%")
                                 ->where('university_level', '=', "$university_level")
                                 ->where('min2019','between',["$score_min", "$score_max"])
                                 ->where('min2019','between',["$pos_min", "$pos_max"])
                                 ->where($where985)
                                 ->where($where211)
                                 ->where($wherefc)
                                 ->where('state', 1)
                                 ->paginate(10, false, $config);
            } else {
                $voluntary = Db::table('exam_major_university')
                                 ->where('major_name', 'like', "%$major_name%")
                                 ->where('province', "=", "$province")
                                 ->where('university_name', 'like', "%$university_name%")
                                 ->where('university_level', '=', "$university_level")
                                 ->where('min2019','between',["$score_min", "$score_max"])
                                 ->where('min2019','between',["$pos_min", "$pos_max"])
                                 ->where($where985)
                                 ->where($where211)
                                 ->where($wherefc)
                                 ->where('state', 1)
                                 ->paginate(10, false, $config);
            }
        } else {
            if ($province == "全部") {
                $voluntary = Db::table('exam_major_university')
                                 ->where('major_name', 'like', "%$major_name%")
                                 ->where('major_level', "=", "$major_level")
                                 ->where('university_name', 'like', "%$university_name%")
                                 ->where('university_level', '=', "$university_level")
                                 ->where('min2019','between',["$score_min", "$score_max"])
                                 ->where('min2019','between',["$pos_min", "$pos_max"])
                                 ->where($where985)
                                 ->where($where211)
                                 ->where($wherefc)
                                 ->where('state', 1)
                                 ->paginate(10, false, $config);
            } else {
                $voluntary = Db::table('exam_major_university')
                                 ->where('major_name', 'like', "%$major_name%")
                                 ->where('major_level', "=", "$major_level")
                                 ->where('province', "=", "$province")
                                 ->where('university_name', 'like', "%$university_name%")
                                 ->where('university_level', '=', "$university_level")
                                 ->where('min2019','between',["$score_min", "$score_max"])
                                 ->where('min2019','between',["$pos_min", "$pos_max"])
                                 ->where($where985)
                                 ->where($where211)
                                 ->where($wherefc)
                                 ->where('state', 1)
                                 ->paginate(10, false, $config);
            }
        }
        $this->assign('voluntary', $voluntary);
    	return $this->fetch();
    }
}
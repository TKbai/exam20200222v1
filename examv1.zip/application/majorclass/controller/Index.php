<?php
/**
 * 文件名：index.php
 * 描述：专业库控制器
 * 作者：白亚鑫
 * 日期：2020年2月28日
 * 版本号：V1.0
 * 版权：济南凤鸣科技工作室
 * 修改人：
 * 修改日期：
 * 修改原因：
 */
namespace app\majorclass\controller;

use think\Controller;
use think\Db;
use think\Request;

class Index extends Controller
{
    /**
     * @return mixed
     */
    public function index()
    {
        $majors = Db::table('exam_major1')
            ->where('state', 1)
            ->paginate(10);
        $this->assign("majors", $majors);
        return $this->fetch();
    }

    /**
     * 添加数据
     * @return mixed
     */
    public function add()
    {
        if (Request::instance()->isPost()) {
            $major = Request::instance()->param();
            $result = Db::table('exam_major1')
                ->insert($major);
            if ($result == true) {
                $this->success('添加成功！', url('index'), '', 1);
            } else {
                $this->error('添加失败！', '', '', 1);
            }
        } else {
            return $this->fetch();
        }
    }

    /**
     * 修改数据
     * @return mixed|void
     * @throws \think\Exception
     * @throws \think\db\exception\universitiesNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \think\exception\PDOException
     */
    public function edit()
    {
        $majorId = Request::instance()->param('id');
        if (Request::instance()->isPost()) {
            $major = Request::instance()->param();
            $result = Db::table('exam_major1')
                ->where('id', $majorId)
                ->update($major);
            if ($result == true) {
                $this->success('修改成功！', url('index'), '', 1);
                return;
            } else {
                $this->error('修改失败！', '', '', 1);
            }
        } else {
            $majorInfo = Db::table('exam_major1')
                ->where('id', $majorId)
                ->find();
            $this->assign('major', $majorInfo);
            return $this->fetch();
        }
    }

    /**
     * 删除数据
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     */
    public function delete()
    {
        $major = Request::instance()->param('id');
        $major = array(
            'state' => 0,
        );
        $result = Db::table('exam_major1')
            ->where('id', majorId)
            ->update($major);
        if ($result == true) {
            $this->success('删除成功！', url('index'), '', 1);
            return;
        } else {
            $this->error('删除失败！', '', '', 1);
        }
    }

    /**
     * 查询数据
     * @return mixed
     * @throws \think\exception\DbException
     */
   public function majorclass()
    {
        $class = input('class');
        $category = input('category');
        $config = ['query'=>[]];
        $config['query'] ['class'] = $class;
        $config['query'] ['category'] = $category;
        $majors = Db::table('exam_major1')
                            ->where('class', 'like', "%$class%")
                            ->where('category', 'like', "%$category%")
                            ->where('state', 1)
                            ->paginate(10, false, $config);
        $this->assign('majors', $majors);
        return $this->fetch();
    } 
} 
<?php
/**
 * 文件名：index.php
 * 描述：通知公告控制器
 * 作者：刘增昆
 * 日期：2020年2月14日
 * 版本号：V1.0
 * 版权：济南凤鸣科技有限公司
 * 修改人：
 * 修改日期：
 * 修改原因：
 */
namespace app\notice\controller;

use think\Controller;
use think\Db;
use think\Request;

class Index extends Controller
{
    public function notice()
    {
    	return $this->fetch();
    }
    
    public function index()
    {
        $notices = Db::table('exam_notice')->where('state',1)->paginate(10);
        $this->assign("notices", $notices);
        return $this->fetch();
    }
    
    /**
     * 添加公告
     * @return mixed
     */
    public function add()
    {
        if (Request::instance()->isPost()) {
            $notice = Request::instance()->param(); //添加公告
						if ($notice['notice_date'] == '') {
							$notice['notice_date'] = null;
						}
            $result = Db::table('exam_notice')->insert($notice);
            if ($result == true) {
                $this->success('添加公告成功！', url('index'), '', 1);
            } else {
                $this->error('添加公告失败！', '', '', 1);
            }
        } else {
            return $this->fetch();
        }
    }

    /**
     * 修改公告
     * @return mixed|void
     * @throws \think\Exception
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \think\exception\PDOException
     */
    public function edit()
    {
        $noticeId = Request::instance()->param('notice_id');
        if (Request::instance()->isPost()) {
            $notice = Request::instance()->param();
						if ($notice['notice_date'] == '') {
						$notice['notice_date'] = null;
						}
            $result = Db::table('exam_notice')->where('notice_id', $noticeId)->update($notice);
            if ($result == true) {
                $this->success('修改公告成功！', url('index'), '', 1);
                return;
            } else {
                $this->error('修改公告失败！', '', '', 1);
            }
        } else {
            $noticeInfo = Db::table('exam_notice')->where('notice_id', $noticeId)->find();
            $this->assign('notice', $noticeInfo);
            return $this->fetch();
        }
    }

    /**
     * 删除公告
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     */
    public function delete()
    {
        $noticeId = Request::instance()->param('notice_id');
        $notice = array(
            'state' => 0,
        );
        $result = Db::table('exam_notice')->where('notice_id', $noticeId)->update($notice);
        if ($result == true) {
            $this->success('删除公告成功！', url('index'), '', 1);
            return;
        } else {
            $this->error('删除公告失败！', '', '', 1);
        }
    }
}	

<?php
/**
 * 文件名：index.php
 * 描述：院校库控制器
 * 作者：刘增昆
 * 日期：2020年2月28日
 * 版本号：V1.0
 * 版权：济南凤鸣科技工作室index/
 * 修改人：
 * 修改日期：
 * 修改原因：
 */
namespace app\university\controller;

use think\Controller;
use think\Db;
use think\Request;

class Index extends Controller
{
    /**
     * @return mixed
     */
    public function index()
    {
        $universities = Db::table('exam_university')
            ->where('state', 1)
            ->paginate(10);
        $this->assign("universities", $universities);
        return $this->fetch();
    }

    /**
     * 添加数据
     * @return mixed
     */
    public function add()
    {
        if (Request::instance()->isPost()) {
            $university = Request::instance()->param();
            $result = Db::table('exam_university')
                ->insert($university);
            if ($result == true) {
                $this->success('添加成功！', url('index'), '', 1);
            } else {
                $this->error('添加失败！', '', '', 1);
            }
        } else {
            return $this->fetch();
        }
    }

    /**
     * 修改数据
     * @return mixed|void
     * @throws \think\Exception
     * @throws \think\db\exception\universitiesNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     * @throws \think\exception\PDOException
     */
    public function edit()
    {
        $universityId = Request::instance()->param('university_id');
        if (Request::instance()->isPost()) {
            $university = Request::instance()->param();
            $result = Db::table('exam_university')
                          ->where('university_id', $universityId)
                          ->update($university);
            if ($result == true) {
                $this->success('修改成功！', url('index'), '', 1);
                return;
            } else {
                $this->error('修改失败！', '', '', 1);
            }
        } else {
            $universityInfo = Db::table('exam_university')
                                  ->where('university_id', $universityId)
                                  ->find();
            $this->assign('', $universityInfo);
            return $this->fetch();
        }
    }

    /**
     * 删除数据
     * @throws \think\Exception
     * @throws \think\exception\PDOException
     */
    public function delete()
    {
        $universityId = Request::instance()->param('university_id');
        $university = array(
            'state' => 0,
        );
        $result = Db::table('exam_university')
                      ->where('university_id', $universityId)
                      ->update($university);
        if ($result == true) {
            $this->success('删除成功！', url('index'), '', 1);
            return;
        } else {
            $this->error('删除失败！', '', '', 1);
        }
    }

    /**
     * 查询数据
     * @return mixed
     * @throws \think\exception\DbException
     */
    public function university()
    {
        $university_name = input('university_name');
        $type = input('type');
        $university_level = input('university_level');
        $level = input('level');
        $config = ['query'=>[]];
        $config['query'] ['university_name'] = $university_name;
        $config['query'] ['type'] = $type;
        $config['query'] ['university_level'] = $university_level;
        ($level == 1) ? $config['query'] ['level'] = 1 : '';
        ($level == 2) ? $config['query'] ['level'] = 2 : '';
        ($level == 3) ? $config['query'] ['level'] = 3 : '';
        ($level == 1) ? $where985 = ['university_985' => 1] : $where985=[];
        ($level == 2) ? $where211 = ['university_211' => 1] : $where211=[];
        ($level == 3) ? $wherefc = ['first_class' => 1] : $wherefc=[];
        if ($type == "全部") {
            $universities = Db::table('exam_university')
                                ->where('university_name', 'like', "%$university_name%")
                                ->where('university_level', '=', "$university_level")
                                ->where($where985)
                                ->where($where211)
                                ->where($wherefc)
                                ->where('state', 1)
                                ->paginate(10, false, $config);
        } else {
            $universities = Db::table('exam_university')
                                ->where('university_name', 'like', "%$university_name%")
                                ->where('type', '=', "$type")
                                ->where('university_level', '=', "$university_level")
                                ->where($where985)
                                ->where($where211)
                                ->where($wherefc)
                                ->where('state', 1)
                                ->paginate(10, false, $config);
        }
        $this->assign('universities', $universities);
        return $this->fetch();
    }
}